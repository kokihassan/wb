<?php
// ============================================================
// DATABASE CONFIG - غيّر هذه القيم
// ============================================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'restaurant_bot');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
define('DB_CHARSET', 'utf8mb4');

// ============================================================
// API KEYS
// ============================================================
define('GEMINI_API_KEY', 'YOUR_GEMINI_API_KEY');
define('WAHA_URL', 'https://your-waha-instance.render.com');
define('WAHA_API_KEY', 'YOUR_WAHA_API_KEY');
define('WAHA_SESSION', 'default');

// ============================================================
// APP CONFIG
// ============================================================
define('APP_URL', 'https://yourdomain.infinityfreeapp.com');
define('UPLOAD_PATH', __DIR__ . '/uploads/');
define('UPLOAD_URL', APP_URL . '/uploads/');
define('JWT_SECRET', 'CHANGE_THIS_TO_RANDOM_64_CHAR_STRING');
define('ADMIN_SESSION_LIFETIME', 86400);

// ============================================================
// CORS
// ============================================================
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit(); }

// ============================================================
// DATABASE
// ============================================================
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['error' => 'Database connection failed']));
        }
    }
    return $pdo;
}

// ============================================================
// RESPONSES
// ============================================================
function success($data = [], $message = 'success', $code = 200) {
    http_response_code($code);
    echo json_encode(['success' => true, 'message' => $message, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit();
}

function error($message = 'Error', $code = 400, $data = []) {
    http_response_code($code);
    echo json_encode(['success' => false, 'message' => $message, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit();
}

// ============================================================
// JWT AUTH
// ============================================================
function generateToken($payload) {
    $header = rtrim(base64_encode(json_encode(['alg'=>'HS256','typ'=>'JWT'])), '=');
    $payload['iat'] = time();
    $payload['exp'] = time() + ADMIN_SESSION_LIFETIME;
    $payload = rtrim(base64_encode(json_encode($payload)), '=');
    $sig = rtrim(base64_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true)), '=');
    return "$header.$payload.$sig";
}

function verifyToken($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return false;
    [$h, $p, $s] = $parts;
    $expected = rtrim(base64_encode(hash_hmac('sha256', "$h.$p", JWT_SECRET, true)), '=');
    if (!hash_equals($s, $expected)) return false;
    $data = json_decode(base64_decode($p . str_repeat('=', 4 - strlen($p) % 4)), true);
    if (!$data || $data['exp'] < time()) return false;
    return $data;
}

function requireAuth() {
    $headers = getallheaders();
    $auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    if (!str_starts_with($auth, 'Bearer ')) error('Unauthorized', 401);
    $data = verifyToken(substr($auth, 7));
    if (!$data) error('Invalid or expired token', 401);
    return $data;
}

// ============================================================
// FILE UPLOAD
// ============================================================
function uploadImage($file, $folder = 'items') {
    $uploadDir = UPLOAD_PATH . $folder . '/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    $allowed = ['jpg','jpeg','png','webp','gif'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed) || $file['size'] > 5*1024*1024) return false;
    $filename = uniqid() . '_' . time() . '.' . $ext;
    if (move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
        return UPLOAD_URL . $folder . '/' . $filename;
    }
    return false;
}

// ============================================================
// ORDER NUMBER
// ============================================================
function generateOrderNumber() {
    $db = getDB();
    $stmt = $db->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()");
    $count = $stmt->fetchColumn() + 1;
    return 'ORD-' . date('Ymd') . '-' . str_pad($count, 4, '0', STR_PAD_LEFT);
}

// ============================================================
// SEND WHATSAPP (via WAHA)
// ============================================================
function sendWhatsApp($number, $message, $imageUrl = null) {
    $url = WAHA_URL . '/api/sendText';
    $data = [
        'session' => WAHA_SESSION,
        'chatId'  => $number . '@c.us',
        'text'    => $message
    ];
    
    if ($imageUrl) {
        $url = WAHA_URL . '/api/sendImage';
        $data = [
            'session' => WAHA_SESSION,
            'chatId'  => $number . '@c.us',
            'file'    => ['url' => $imageUrl],
            'caption' => $message
        ];
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'X-Api-Key: ' . WAHA_API_KEY
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
    ]);
    $result = curl_exec($ch);
    curl_close($ch);
    return json_decode($result, true);
}
