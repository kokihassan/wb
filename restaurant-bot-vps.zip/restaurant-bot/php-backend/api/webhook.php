<?php
// api/webhook.php
// هذا الملف يستقبل الرسائل من WAHA ويمررها للـ Node bot
// أو يمكن استخدامه كـ fallback لو Node bot كان offline

require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// ─── WAHA Webhook (receive messages) ─────────────────────────
if ($method === 'POST' && $action === 'waha') {
    $raw = file_get_contents('php://input');
    $event = json_decode($raw, true);
    
    // Log raw webhook (for debugging)
    $logFile = __DIR__ . '/../logs/webhook_' . date('Y-m-d') . '.log';
    $logDir = dirname($logFile);
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    file_put_contents($logFile, date('H:i:s') . ' ' . $raw . "\n", FILE_APPEND);
    
    // Only process incoming text messages
    if (($event['event'] ?? '') !== 'message' || ($event['payload']['fromMe'] ?? false)) {
        http_response_code(200);
        exit('ok');
    }
    
    $number = str_replace('@c.us', '', $event['payload']['from'] ?? '');
    $text   = $event['payload']['body'] ?? '';
    $type   = $event['payload']['type'] ?? '';
    
    if (!$number || !$text || $type !== 'chat') {
        http_response_code(200);
        exit('ok');
    }
    
    // Forward to Node bot
    $nodeUrl = defined('NODE_BOT_URL') ? NODE_BOT_URL : 'https://your-bot.render.com';
    
    $ch = curl_init($nodeUrl . '/webhook');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $raw,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 5,
        CURLOPT_NOSIGNAL       => 1,
    ]);
    curl_exec($ch);
    curl_close($ch);
    
    http_response_code(200);
    exit('ok');
}

// ─── Test webhook connectivity ─────────────────────────────────
if ($method === 'GET' && $action === 'test') {
    success(['message' => 'Webhook is working!', 'timestamp' => date('Y-m-d H:i:s')]);
}

// ─── Get webhook logs ──────────────────────────────────────────
if ($method === 'GET' && $action === 'logs') {
    requireAuth();
    $logFile = __DIR__ . '/../logs/webhook_' . date('Y-m-d') . '.log';
    if (file_exists($logFile)) {
        $lines = array_slice(file($logFile), -50); // Last 50 lines
        success(['logs' => $lines]);
    }
    success(['logs' => []]);
}

http_response_code(404);
echo json_encode(['error' => 'Not found']);
