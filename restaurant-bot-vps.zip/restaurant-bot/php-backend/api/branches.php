<?php
// api/branches.php
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_GET['action'] ?? '', '/'));
$action = $path[0] ?? '';

switch("$method:$action") {

    case 'GET:list':
        $db = getDB();
        $branches = $db->query("SELECT * FROM branches ORDER BY sort_order")->fetchAll();
        foreach ($branches as &$b) {
            $zones = $db->prepare("SELECT * FROM delivery_zones WHERE branch_id=? ORDER BY sort_order");
            $zones->execute([$b['id']]);
            $b['zones'] = $zones->fetchAll();
            $hours = $db->prepare("SELECT * FROM working_hours WHERE branch_id=? ORDER BY day_of_week");
            $hours->execute([$b['id']]);
            $b['working_hours'] = $hours->fetchAll();
        }
        success($branches);

    case 'POST:create':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO branches (name, address, phone, whatsapp_number, notification_phone, latitude, longitude, is_active, sort_order) VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$data['name'], $data['address'], $data['phone']??null, $data['whatsapp_number']??null, $data['notification_phone']??null, $data['latitude']??null, $data['longitude']??null, $data['is_active']??1, $data['sort_order']??0]);
        $branchId = $db->lastInsertId();
        
        // Auto-create branch availability for all menu items
        $items = $db->query("SELECT id FROM menu_items")->fetchAll();
        foreach ($items as $item) {
            $db->prepare("INSERT IGNORE INTO item_branch_availability (item_id, branch_id, is_available) VALUES (?,?,1)")
               ->execute([$item['id'], $branchId]);
        }
        success(['id' => $branchId], 'تم إضافة الفرع', 201);

    case 'PUT:update':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing ID');
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("UPDATE branches SET name=?, address=?, phone=?, whatsapp_number=?, notification_phone=?, latitude=?, longitude=?, is_active=?, sort_order=? WHERE id=?");
        $stmt->execute([$data['name'], $data['address'], $data['phone']??null, $data['whatsapp_number']??null, $data['notification_phone']??null, $data['latitude']??null, $data['longitude']??null, $data['is_active']??1, $data['sort_order']??0, $id]);
        success([], 'تم التحديث');

    case 'PUT:toggle':
        requireAuth();
        $id = $path[1] ?? null;
        $db = getDB();
        $db->prepare("UPDATE branches SET is_active = NOT is_active WHERE id=?")->execute([$id]);
        success([], 'تم التحديث');

    // ─── Zones ────────────────────────────────────────────────────
    case 'POST:zones':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO delivery_zones (branch_id, zone_name, delivery_price, delivery_time_minutes, min_order_amount, notes, is_active, sort_order) VALUES (?,?,?,?,?,?,?,?)");
        $stmt->execute([$data['branch_id'], $data['zone_name'], $data['delivery_price'], $data['delivery_time_minutes']??45, $data['min_order_amount']??0, $data['notes']??null, $data['is_active']??1, $data['sort_order']??0]);
        success(['id' => $db->lastInsertId()], 'تم إضافة المنطقة', 201);

    case 'PUT:zones':
        requireAuth();
        $id = $path[1] ?? null;
        if (!$id) error('Missing ID');
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("UPDATE delivery_zones SET zone_name=?, delivery_price=?, delivery_time_minutes=?, min_order_amount=?, notes=?, is_active=?, sort_order=? WHERE id=?");
        $stmt->execute([$data['zone_name'], $data['delivery_price'], $data['delivery_time_minutes']??45, $data['min_order_amount']??0, $data['notes']??null, $data['is_active']??1, $data['sort_order']??0, $id]);
        success([], 'تم التحديث');

    case 'DELETE:zones':
        requireAuth();
        $id = $path[1] ?? null;
        $db = getDB();
        $db->prepare("DELETE FROM delivery_zones WHERE id=?")->execute([$id]);
        success([], 'تم الحذف');

    // ─── Find zone by area name ───────────────────────────────────
    case 'GET:find-zone':
        $area = $_GET['area'] ?? '';
        $db = getDB();
        $stmt = $db->prepare("SELECT dz.*, b.name as branch_name, b.id as branch_id 
            FROM delivery_zones dz JOIN branches b ON dz.branch_id=b.id
            WHERE dz.is_active=1 AND b.is_active=1
            AND LOWER(dz.zone_name) LIKE LOWER(?)");
        $stmt->execute(["%$area%"]);
        success($stmt->fetchAll());

    // ─── Working Hours ─────────────────────────────────────────────
    case 'POST:working-hours':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        foreach ($data['hours'] as $hour) {
            $stmt = $db->prepare("INSERT INTO working_hours (branch_id, day_of_week, open_time, close_time, is_closed) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE open_time=VALUES(open_time), close_time=VALUES(close_time), is_closed=VALUES(is_closed)");
            $stmt->execute([$data['branch_id'], $hour['day_of_week'], $hour['open_time'], $hour['close_time'], $hour['is_closed']??0]);
        }
        success([], 'تم حفظ أوقات العمل');

    default:
        error('Action not found', 404);
}
