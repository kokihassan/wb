<?php
// index.php - Main API Router

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = preg_replace('#^/api/?#', '', $uri);
$uri = trim($uri, '/');
$parts = explode('/', $uri);

$resource = $parts[0] ?? '';
$action   = implode('/', array_slice($parts, 1));

// Pass action to sub-files via GET
$_GET['action'] = $action;

switch ($resource) {
    case 'menu':      require 'api/menu.php';      break;
    case 'orders':    require 'api/orders.php';    break;
    case 'branches':  require 'api/branches.php';  break;
    case 'customers': require 'api/customers.php'; break;
    case 'coupons':   require 'api/coupons.php';   break;
    case 'settings':  require 'api/settings.php';  break;
    case 'auth':      require 'api/auth.php';      break;
    case 'webhook':   require 'api/webhook.php';   break;
    case 'offers':    require 'api/offers.php';    break;
    case 'reports':   require 'api/reports.php';   break;
    case 'health':
        header('Content-Type: application/json');
        echo json_encode(['status' => 'ok', 'time' => date('Y-m-d H:i:s')]);
        break;
    default:
        http_response_code(404);
        echo json_encode(['error' => 'Not found', 'uri' => $uri]);
}
