import { useState, useEffect, useRef } from "react";

// ══════════════════════════════════════════════════════════════
// CONFIG — غيّر هذا السطر لرابط API بتاعك
// ══════════════════════════════════════════════════════════════
const API_BASE = "https://yourdomain.infinityfreeapp.com/api";

// ─── API Helper ───────────────────────────────────────────────
async function api(method, path, data = null, token = null) {
  try {
    const headers = {};
    if (token) headers["Authorization"] = `Bearer ${token}`;
    let body = null;
    if (data && !(data instanceof FormData)) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(data);
    } else if (data instanceof FormData) {
      body = data;
    }
    const res = await fetch(`${API_BASE}/${path}`, { method, headers, body });
    return res.json();
  } catch (e) {
    return { success: false, message: e.message };
  }
}

// ─── SVG Icons ────────────────────────────────────────────────
const PATHS = {
  chart: "M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z",
  dashboard: "M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6",
  menu: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2",
  orders: "M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z",
  branches: "M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z",
  customers: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z",
  coupons: "M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z",
  settings: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z",
  plus: "M12 4v16m8-8H4",
  edit: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z",
  trash: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16",
  upload: "M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12",
  x: "M6 18L18 6M6 6l12 12",
  logout: "M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1",
  search: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z",
  eye: "M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z",
  refresh: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15",
  ban: "M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636",
};
const Icon = ({ n, size = 18 }) => (
  <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24">
    <path d={PATHS[n] || PATHS.dashboard} />
  </svg>
);

// ─── Reusable Components ──────────────────────────────────────
const Spinner = () => (
  <div className="flex justify-center items-center py-16">
    <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
  </div>
);

const Toast = ({ msg, type, onClose }) => (
  <div className={`fixed top-5 left-1/2 -translate-x-1/2 z-[999] flex items-center gap-3 px-6 py-3.5 rounded-2xl shadow-2xl text-white font-bold text-sm transition-all animate-bounce ${type === "error" ? "bg-red-500" : "bg-emerald-500"}`}>
    <span>{type === "error" ? "✕" : "✓"}</span>
    {msg}
    <button onClick={onClose} className="opacity-70 hover:opacity-100 mr-1">×</button>
  </div>
);

const Modal = ({ title, onClose, children, maxW = "max-w-lg" }) => (
  <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
    <div className={`bg-white rounded-3xl ${maxW} w-full max-h-[92vh] overflow-y-auto shadow-2xl`} onClick={e => e.stopPropagation()}>
      <div className="flex items-center justify-between p-6 border-b border-gray-100 sticky top-0 bg-white rounded-t-3xl z-10">
        <h3 className="text-xl font-black text-gray-900">{title}</h3>
        <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-500 transition-colors">
          <Icon n="x" size={16} />
        </button>
      </div>
      <div className="p-6">{children}</div>
    </div>
  </div>
);

const Toggle = ({ checked, onChange, size = "md" }) => (
  <button onClick={onChange}
    className={`relative rounded-full transition-colors flex-shrink-0 ${size === "sm" ? "w-10 h-5" : "w-12 h-6"} ${checked ? "bg-emerald-400" : "bg-gray-300"}`}>
    <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${size === "sm" ? "w-4 h-4" : "w-5 h-5"} ${checked ? "right-0.5" : "left-0.5"}`} />
  </button>
);

const Field = ({ label, children }) => (
  <div>
    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1.5">{label}</label>
    {children}
  </div>
);

const Input = ({ ...props }) => (
  <input {...props} className={`w-full border-2 border-gray-200 rounded-xl px-4 py-2.5 focus:border-amber-400 focus:outline-none text-sm transition-colors ${props.className || ""}`} />
);

const Textarea = ({ ...props }) => (
  <textarea {...props} className={`w-full border-2 border-gray-200 rounded-xl px-4 py-2.5 focus:border-amber-400 focus:outline-none text-sm transition-colors resize-none ${props.className || ""}`} />
);

const Select = ({ children, ...props }) => (
  <select {...props} className={`w-full border-2 border-gray-200 rounded-xl px-4 py-2.5 focus:border-amber-400 focus:outline-none text-sm bg-white transition-colors ${props.className || ""}`}>
    {children}
  </select>
);

const Btn = ({ children, variant = "primary", size = "md", className = "", ...props }) => {
  const base = "inline-flex items-center justify-center gap-2 font-bold rounded-xl transition-all disabled:opacity-50";
  const sizes = { sm: "px-3 py-1.5 text-xs", md: "px-5 py-2.5 text-sm", lg: "px-6 py-3 text-base" };
  const variants = {
    primary: "bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:from-amber-600 hover:to-orange-600 shadow-md hover:shadow-lg",
    secondary: "bg-gray-100 text-gray-700 hover:bg-gray-200",
    danger: "bg-red-100 text-red-600 hover:bg-red-200",
    success: "bg-emerald-100 text-emerald-700 hover:bg-emerald-200",
    ghost: "text-gray-500 hover:text-gray-700 hover:bg-gray-100",
  };
  return <button {...props} className={`${base} ${sizes[size]} ${variants[variant]} ${className}`}>{children}</button>;
};

const StatusBadge = ({ status }) => {
  const map = {
    new: ["bg-blue-100 text-blue-700 border-blue-200", "جديد 🔵"],
    confirmed: ["bg-indigo-100 text-indigo-700 border-indigo-200", "مؤكد"],
    preparing: ["bg-amber-100 text-amber-700 border-amber-200", "قيد التحضير 🔥"],
    ready: ["bg-purple-100 text-purple-700 border-purple-200", "جاهز ✨"],
    out_for_delivery: ["bg-orange-100 text-orange-700 border-orange-200", "في الطريق 🛵"],
    delivered: ["bg-emerald-100 text-emerald-700 border-emerald-200", "تم التسليم ✅"],
    cancelled: ["bg-red-100 text-red-600 border-red-200", "ملغي ✕"],
  };
  const [cls, label] = map[status] || ["bg-gray-100 text-gray-600 border-gray-200", status];
  return <span className={`px-2.5 py-1 rounded-lg text-xs font-bold border ${cls}`}>{label}</span>;
};

// ══════════════════════════════════════════════════════════════
// LOGIN PAGE
// ══════════════════════════════════════════════════════════════
const LoginPage = ({ onLogin }) => {
  const [form, setForm] = useState({ email: "admin@restaurant.com", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const login = async () => {
    if (!form.password) return setError("أدخل كلمة المرور");
    setLoading(true); setError("");
    const res = await api("POST", "auth/login", form);
    setLoading(false);
    if (res.success) {
      localStorage.setItem("rtoken", res.data.token);
      localStorage.setItem("ruser", JSON.stringify(res.data.user));
      onLogin(res.data.token, res.data.user);
    } else setError(res.message || "بيانات خاطئة");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-100 flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <div className="w-24 h-24 bg-gradient-to-br from-amber-400 to-orange-500 rounded-3xl mx-auto mb-5 flex items-center justify-center text-4xl shadow-2xl rotate-3">🍽️</div>
          <h1 className="text-4xl font-black text-gray-900 tracking-tight">لوحة التحكم</h1>
          <p className="text-gray-500 mt-2 text-sm">نظام إدارة المطعم الذكي</p>
        </div>
        <div className="bg-white/80 backdrop-blur rounded-3xl shadow-2xl p-8 space-y-5 border border-white">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-600 rounded-2xl p-4 text-sm font-medium">
              ⚠️ {error}
            </div>
          )}
          <Field label="البريد الإلكتروني">
            <Input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
          </Field>
          <Field label="كلمة المرور">
            <Input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} onKeyDown={e => e.key === "Enter" && login()} placeholder="••••••••" />
          </Field>
          <Btn variant="primary" size="lg" className="w-full" onClick={login} disabled={loading}>
            {loading ? "⏳ جاري الدخول..." : "دخول ←"}
          </Btn>
          <p className="text-center text-xs text-gray-400">كلمة المرور الافتراضية: <code className="bg-gray-100 px-2 py-0.5 rounded font-mono">password</code></p>
        </div>
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════════════════
// DASHBOARD PAGE
// ══════════════════════════════════════════════════════════════
const DashboardPage = ({ token }) => {
  const [stats, setStats] = useState(null);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const res = await api("GET", `orders/stats?date=${date}`, null, token);
    if (res.success) setStats(res.data);
    setLoading(false);
  };

  useEffect(() => { load(); const t = setInterval(load, 30000); return () => clearInterval(t); }, [date]);

  if (loading) return <Spinner />;

  const t = stats?.today || {};
  const statCards = [
    { label: "إجمالي الطلبات", value: t.total_orders || 0, icon: "📦", from: "from-blue-500", to: "to-blue-600" },
    { label: "الإيرادات اليوم", value: `${parseFloat(t.total_revenue || 0).toFixed(0)} ج`, icon: "💰", from: "from-emerald-500", to: "to-emerald-600" },
    { label: "توصيل", value: t.delivery_count || 0, icon: "🛵", from: "from-orange-500", to: "to-orange-600" },
    { label: "تيك أواي", value: t.takeaway_count || 0, icon: "🥡", from: "from-purple-500", to: "to-purple-600" },
    { label: "طلبات جديدة الآن", value: stats?.new_orders_count || 0, icon: "🔔", from: "from-red-500", to: "to-red-600" },
    { label: "متوسط الطلب", value: `${parseFloat(t.avg_order_value || 0).toFixed(0)} ج`, icon: "📊", from: "from-teal-500", to: "to-teal-600" },
  ];

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-black text-gray-900">الداشبورد 📊</h2>
          <p className="text-sm text-gray-500 mt-0.5">مرحباً، إليك ملخص اليوم</p>
        </div>
        <div className="flex items-center gap-3">
          <Input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-40 text-sm" />
          <Btn variant="secondary" size="sm" onClick={load}><Icon n="refresh" size={14} /></Btn>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {statCards.map((c, i) => (
          <div key={i} className={`bg-gradient-to-br ${c.from} ${c.to} rounded-2xl p-5 text-white shadow-lg hover:shadow-xl transition-shadow`}>
            <div className="text-3xl mb-3">{c.icon}</div>
            <div className="text-3xl font-black leading-none">{c.value}</div>
            <div className="text-white/80 text-xs mt-2 font-medium">{c.label}</div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        {/* Top Items */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h3 className="font-black text-gray-800 mb-5 flex items-center gap-2">
            <span className="text-xl">🔥</span> أكثر الأصناف طلباً
          </h3>
          <div className="space-y-3">
            {(stats?.top_items || []).length === 0 && <p className="text-gray-400 text-sm text-center py-4">لا بيانات اليوم</p>}
            {(stats?.top_items || []).map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black text-white ${["bg-amber-400","bg-gray-400","bg-orange-400","bg-teal-400","bg-blue-400"][i]}`}>{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-gray-800 text-sm truncate">{item.item_name}</div>
                  <div className="w-full bg-gray-100 rounded-full h-1.5 mt-1">
                    <div className="bg-amber-400 h-1.5 rounded-full" style={{ width: `${Math.min(100, (item.total_qty / (stats.top_items[0]?.total_qty || 1)) * 100)}%` }} />
                  </div>
                </div>
                <div className="text-right text-xs text-gray-500 flex-shrink-0">
                  <div className="font-bold text-gray-800">{item.total_qty} طلب</div>
                  <div>{parseFloat(item.revenue || 0).toFixed(0)} ج</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Orders */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h3 className="font-black text-gray-800 mb-5 flex items-center gap-2">
            <span className="text-xl">🕐</span> آخر الطلبات
          </h3>
          <div className="space-y-2">
            {(stats?.recent_orders || []).length === 0 && <p className="text-gray-400 text-sm text-center py-4">لا طلبات بعد</p>}
            {(stats?.recent_orders || []).map((o, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 transition-colors">
                <div className="min-w-0">
                  <div className="font-bold text-xs text-gray-800">{o.order_number}</div>
                  <div className="text-xs text-gray-500 truncate">{o.customer_name}</div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <StatusBadge status={o.status} />
                  <span className="text-xs font-bold text-amber-600">{parseFloat(o.total_amount || 0).toFixed(0)}ج</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Status breakdown */}
      {(stats?.by_status || []).length > 0 && (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h3 className="font-black text-gray-800 mb-4">توزيع الطلبات حسب الحالة</h3>
          <div className="flex flex-wrap gap-3">
            {(stats.by_status || []).map((s, i) => (
              <div key={i} className="flex items-center gap-2 bg-gray-50 rounded-xl px-4 py-3">
                <StatusBadge status={s.status} />
                <span className="font-black text-gray-900">{s.count}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════════════
// ORDERS PAGE
// ══════════════════════════════════════════════════════════════
const OrdersPage = ({ token }) => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [filter, setFilter] = useState("all");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [newCount, setNewCount] = useState(0);
  const prevNew = useRef(0);

  const STATUS_FLOW = ["new","confirmed","preparing","ready","out_for_delivery","delivered"];
  const NEXT_LABELS = { confirmed:"✅ تأكيد الطلب", preparing:"👨‍🍳 بدء التحضير", ready:"✨ جاهز", out_for_delivery:"🛵 خرج للتوصيل", delivered:"✅ تم التسليم" };

  const load = async () => {
    const q = `orders/list?date=${date}${filter !== "all" ? `&status=${filter}` : ""}`;
    const res = await api("GET", q, null, token);
    if (res.success) {
      const list = res.data.orders || [];
      const nc = list.filter(o => o.status === "new").length;
      if (nc > prevNew.current && prevNew.current >= 0) {
        // New order arrived!
      }
      prevNew.current = nc;
      setNewCount(nc);
      setOrders(list);
      setLoading(false);
    }
  };

  useEffect(() => { load(); const t = setInterval(load, 12000); return () => clearInterval(t); }, [filter, date]);

  const updateStatus = async (id, status, extra = {}) => {
    await api("PUT", `orders/status/${id}`, { status, ...extra }, token);
    load();
    if (selected?.id === id) setSelected(p => ({ ...p, status }));
  };

  const getNext = s => { const i = STATUS_FLOW.indexOf(s); return i >= 0 && i < STATUS_FLOW.length - 1 ? STATUS_FLOW[i + 1] : null; };

  const filters = [
    { k: "all", l: "الكل" }, { k: "new", l: "🔵 جديد" }, { k: "confirmed", l: "مؤكد" },
    { k: "preparing", l: "🔥 قيد التحضير" }, { k: "ready", l: "✨ جاهز" },
    { k: "out_for_delivery", l: "🛵 في الطريق" }, { k: "delivered", l: "✅ تم" }, { k: "cancelled", l: "ملغي" },
  ];

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <div className="flex items-center gap-3">
          <h2 className="text-2xl font-black text-gray-900">الطلبات</h2>
          {newCount > 0 && (
            <span className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-black animate-pulse shadow-lg">
              🔔 {newCount} جديد!
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-38 text-sm" />
          <Btn variant="secondary" size="sm" onClick={load}><Icon n="refresh" size={14} /></Btn>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {filters.map(f => (
          <button key={f.k} onClick={() => setFilter(f.k)}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex-shrink-0 border-2
              ${filter === f.k ? "bg-amber-500 text-white border-amber-500 shadow-md" : "bg-white text-gray-600 border-gray-200 hover:border-amber-300"}`}>
            {f.l}
          </button>
        ))}
      </div>

      {loading ? <Spinner /> : (
        <div className="space-y-3">
          {orders.length === 0 && (
            <div className="text-center py-20 text-gray-400">
              <div className="text-6xl mb-4">📭</div>
              <p className="font-medium">لا توجد طلبات</p>
            </div>
          )}
          {orders.map(o => (
            <div key={o.id} onClick={() => setSelected(o)}
              className={`bg-white rounded-2xl p-4 border-2 cursor-pointer hover:shadow-md transition-all
                ${o.status === "new" ? "border-blue-400 bg-blue-50/50 shadow-blue-100 shadow-md" : "border-gray-100 hover:border-amber-200"}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-black text-gray-900 text-sm">{o.order_number}</span>
                  <StatusBadge status={o.status} />
                  <span className={`text-xs px-2 py-0.5 rounded-lg font-medium ${o.order_type === "delivery" ? "bg-orange-100 text-orange-600" : "bg-teal-100 text-teal-600"}`}>
                    {o.order_type === "delivery" ? "🛵 توصيل" : "🥡 تيك أواي"}
                  </span>
                </div>
                <span className="font-black text-amber-600 text-lg">{parseFloat(o.total_amount || 0).toFixed(0)} ج</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm">
                  <span className="font-semibold text-gray-700">{o.customer_name || "عميل"}</span>
                  <span className="text-gray-400 text-xs mr-2">{o.whatsapp_number}</span>
                  {o.zone_name && <span className="text-gray-400 text-xs"> | {o.zone_name}</span>}
                </div>
                <div className="flex gap-2" onClick={e => e.stopPropagation()}>
                  {!["delivered","cancelled"].includes(o.status) && getNext(o.status) && (
                    <Btn variant="primary" size="sm" onClick={() => updateStatus(o.id, getNext(o.status))}>
                      {NEXT_LABELS[getNext(o.status)]}
                    </Btn>
                  )}
                  {!["delivered","cancelled"].includes(o.status) && (
                    <Btn variant="danger" size="sm" onClick={() => updateStatus(o.id, "cancelled")}>إلغاء</Btn>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Order Detail Modal */}
      {selected && (
        <Modal title={selected.order_number} onClose={() => setSelected(null)}>
          <div className="space-y-4">
            <div className="flex gap-2 flex-wrap">
              <StatusBadge status={selected.status} />
              <span className={`text-xs px-2.5 py-1 rounded-lg font-bold border ${selected.order_type === "delivery" ? "bg-orange-100 text-orange-600 border-orange-200" : "bg-teal-100 text-teal-600 border-teal-200"}`}>
                {selected.order_type === "delivery" ? "🛵 توصيل" : "🥡 تيك أواي"}
              </span>
              {selected.payment_method === "cash" && <span className="text-xs px-2.5 py-1 rounded-lg font-bold bg-gray-100 text-gray-600 border border-gray-200">💵 كاش</span>}
            </div>

            <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4 space-y-1.5 text-sm">
              <p className="font-black text-gray-700 mb-2">👤 بيانات العميل</p>
              <p><span className="text-gray-500">الاسم:</span> <span className="font-semibold">{selected.customer_name || "—"}</span></p>
              <p><span className="text-gray-500">الواتساب:</span> <span className="font-semibold">{selected.whatsapp_number}</span></p>
              {selected.recipient_name && selected.recipient_name !== selected.customer_name &&
                <p><span className="text-gray-500">المستلم:</span> <span className="font-semibold">{selected.recipient_name} | {selected.recipient_phone}</span></p>}
              {selected.delivery_address && <p><span className="text-gray-500">العنوان:</span> <span className="font-semibold">{selected.delivery_address}</span></p>}
              {selected.zone_name && <p><span className="text-gray-500">المنطقة:</span> <span className="font-semibold">{selected.zone_name}</span></p>}
            </div>

            <div className="bg-gray-50 rounded-2xl p-4">
              <p className="font-black text-gray-700 mb-3">🛒 الأصناف</p>
              <div className="space-y-2">
                {(selected.items || []).map((item, i) => (
                  <div key={i} className="flex justify-between text-sm">
                    <span className="text-gray-700">{item.quantity}× {item.item_name}{item.size_name ? ` (${item.size_name})` : ""}</span>
                    <span className="font-bold text-gray-900">{parseFloat(item.total_price || 0).toFixed(0)} ج</span>
                  </div>
                ))}
              </div>
              <div className="border-t border-gray-200 mt-3 pt-3 space-y-1.5 text-sm">
                <div className="flex justify-between text-gray-600"><span>المجموع</span><span>{parseFloat(selected.subtotal || 0).toFixed(0)} ج</span></div>
                {parseFloat(selected.delivery_fee) > 0 && <div className="flex justify-between text-gray-600"><span>التوصيل</span><span>{parseFloat(selected.delivery_fee).toFixed(0)} ج</span></div>}
                {parseFloat(selected.discount_amount) > 0 && <div className="flex justify-between text-emerald-600 font-medium"><span>خصم {selected.coupon_code && `(${selected.coupon_code})`}</span><span>- {parseFloat(selected.discount_amount).toFixed(0)} ج</span></div>}
                <div className="flex justify-between font-black text-xl text-amber-600 pt-2 border-t border-gray-200"><span>الإجمالي</span><span>{parseFloat(selected.total_amount || 0).toFixed(0)} ج</span></div>
              </div>
            </div>

            {selected.customer_notes && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4 text-sm">
                <p className="font-bold text-yellow-800 mb-1">📝 ملاحظات العميل</p>
                <p className="text-yellow-700">{selected.customer_notes}</p>
              </div>
            )}

            {selected.estimated_time && !["delivered","cancelled"].includes(selected.status) && (
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-3 text-center text-sm text-blue-700 font-medium">
                ⏱️ الوقت المتوقع: <strong>{selected.estimated_time} دقيقة</strong>
              </div>
            )}

            {selected.rating && (
              <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 text-sm">
                <p className="font-bold text-purple-800 mb-1">⭐ التقييم: {"★".repeat(selected.rating)}{"☆".repeat(5 - selected.rating)}</p>
                {selected.rating_comment && <p className="text-purple-700">{selected.rating_comment}</p>}
              </div>
            )}

            <div className="flex gap-2 flex-wrap">
              {!["delivered","cancelled"].includes(selected.status) && getNext(selected.status) && (
                <Btn variant="primary" size="lg" className="flex-1"
                  onClick={() => { updateStatus(selected.id, getNext(selected.status)); setSelected(p => ({...p, status: getNext(selected.status)})); }}>
                  {NEXT_LABELS[getNext(selected.status)]}
                </Btn>
              )}
              {!["delivered","cancelled"].includes(selected.status) && (
                <Btn variant="danger" onClick={() => { updateStatus(selected.id, "cancelled"); setSelected(null); }}>إلغاء الطلب</Btn>
              )}
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════════════
// MENU PAGE
// ══════════════════════════════════════════════════════════════
const MenuPage = ({ token }) => {
  const [categories, setCategories] = useState([]);
  const [items, setItems] = useState([]);
  const [branches, setBranches] = useState([]);
  const [branchAvail, setBranchAvail] = useState({});
  const [catFilter, setCatFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [showItemForm, setShowItemForm] = useState(false);
  const [showCatForm, setShowCatForm] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [toast, setToast] = useState(null);
  const excelRef = useRef();

  const emptyForm = { category_id:"", name:"", name_en:"", description:"", price:"", preparation_time_minutes:15, calories:"", is_available:1, is_featured:0, is_new:0, is_spicy:0, is_vegetarian:0, sort_order:0 };
  const [form, setForm] = useState(emptyForm);
  const [catForm, setCatForm] = useState({ name:"", name_en:"", icon:"", description:"", sort_order:0 });

  const toast$ = (msg, type="success") => { setToast({msg,type}); setTimeout(()=>setToast(null), 3000); };

  const loadAll = async () => {
    const [c, i, b] = await Promise.all([
      api("GET","menu/categories",null,token),
      api("GET","menu/items",null,token),
      api("GET","branches/list",null,token),
    ]);
    if (c.success) setCategories(c.data || []);
    if (i.success) setItems(i.data || []);
    if (b.success) {
      setBranches(b.data || []);
      // Build branch availability map from items
      const map = {};
      (i.data || []).forEach(item => {
        // We'll load this on demand per item
        map[item.id] = {};
      });
      setBranchAvail(map);
    }
  };

  useEffect(() => { loadAll(); }, []);

  const saveItem = async () => {
    if (!form.name || !form.category_id || !form.price) return toast$("أكمل البيانات المطلوبة", "error");
    const res = editItem
      ? await api("PUT", `menu/items/${editItem.id}`, form, token)
      : await api("POST", "menu/items", form, token);
    if (res.success) { toast$(editItem ? "✅ تم التحديث" : "✅ تمت الإضافة"); setShowItemForm(false); setEditItem(null); loadAll(); }
    else toast$(res.message || "حدث خطأ", "error");
  };

  const saveCat = async () => {
    if (!catForm.name) return toast$("أدخل اسم القسم", "error");
    const res = await api("POST", "menu/categories", catForm, token);
    if (res.success) { toast$("✅ تمت إضافة القسم"); setShowCatForm(false); loadAll(); }
  };

  const uploadImg = (itemId, file) => {
    if (!file) return;
    setUploading(true);
    const fd = new FormData();
    fd.append("image", file);
    fetch(`${API_BASE}/menu/upload-image/${itemId}`, { method:"POST", headers:{ Authorization:`Bearer ${token}` }, body:fd })
      .then(r=>r.json()).then(d=>{ setUploading(false); if(d.success){ toast$("✅ تم رفع الصورة"); loadAll(); } else toast$(d.message||"فشل الرفع","error"); });
  };

  const importExcel = (file) => {
    if (!file) return;
    setUploading(true);
    const fd = new FormData();
    fd.append("file", file);
    fetch(`${API_BASE}/menu/import-excel`, { method:"POST", headers:{ Authorization:`Bearer ${token}` }, body:fd })
      .then(r=>r.json()).then(d=>{ setUploading(false); if(d.success){ toast$(`✅ تم استيراد ${d.data?.imported||0} صنف`); loadAll(); } else toast$(d.message||"فشل الاستيراد","error"); });
  };

  const toggleBranch = async (itemId, branchId, cur) => {
    await api("PUT", "menu/branch-availability", { item_id:itemId, branch_id:branchId, is_available: cur ? 0 : 1 }, token);
    toast$(cur ? "تم إيقاف الصنف في هذا الفرع" : "تم تفعيل الصنف في هذا الفرع");
    loadAll();
  };

  const filtered = items.filter(i =>
    (catFilter === "all" || i.category_id == catFilter) &&
    (!search || i.name.includes(search) || i.category_name?.includes(search))
  );

  return (
    <div className="space-y-5" dir="rtl">
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={()=>setToast(null)} />}

      <div className="flex flex-wrap items-center gap-3 justify-between">
        <h2 className="text-2xl font-black text-gray-900">المنيو 🍽️</h2>
        <div className="flex flex-wrap gap-2">
          <Btn variant="secondary" size="sm" onClick={()=>window.open(`${API_BASE}/menu/excel-template`)}>📥 Template Excel</Btn>
          <Btn variant="secondary" size="sm" onClick={()=>excelRef.current?.click()} disabled={uploading}>
            <Icon n="upload" size={14} /> {uploading ? "..." : "استيراد Excel"}
          </Btn>
          <input ref={excelRef} type="file" accept=".csv,.xlsx" className="hidden" onChange={e=>{ importExcel(e.target.files[0]); e.target.value=""; }} />
          <Btn variant="secondary" size="sm" onClick={()=>setShowCatForm(true)}>📂 قسم جديد</Btn>
          <Btn variant="primary" size="sm" onClick={()=>{ setEditItem(null); setForm(emptyForm); setShowItemForm(true); }}>
            <Icon n="plus" size={14} /> إضافة صنف
          </Btn>
        </div>
      </div>

      {/* Search + filter */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Icon n="search" size={16} />
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="ابحث عن صنف..." className="w-full border-2 border-gray-200 rounded-xl pr-10 pl-4 py-2.5 focus:border-amber-400 outline-none text-sm" style={{paddingRight:"2.5rem"}} />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"><Icon n="search" size={16} /></span>
        </div>
        <div className="flex gap-2 overflow-x-auto">
          <button onClick={()=>setCatFilter("all")} className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex-shrink-0 border-2 transition-all ${catFilter==="all"?"bg-amber-500 text-white border-amber-500":"bg-white border-gray-200 text-gray-600 hover:border-amber-300"}`}>
            الكل ({items.length})
          </button>
          {categories.map(c=>(
            <button key={c.id} onClick={()=>setCatFilter(c.id)} className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex-shrink-0 border-2 transition-all ${catFilter==c.id?"bg-amber-500 text-white border-amber-500":"bg-white border-gray-200 text-gray-600 hover:border-amber-300"}`}>
              {c.icon} {c.name} ({items.filter(i=>i.category_id==c.id).length})
            </button>
          ))}
        </div>
      </div>

      {/* Items grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(item => (
          <div key={item.id} className={`bg-white rounded-2xl overflow-hidden border-2 hover:shadow-lg transition-all ${!item.is_available ? "opacity-60 border-gray-200" : "border-gray-100 hover:border-amber-200"}`}>
            <div className="relative group">
              {item.image
                ? <img src={item.image} alt={item.name} className="w-full h-44 object-cover" />
                : <div className="w-full h-44 bg-gradient-to-br from-amber-100 to-orange-100 flex items-center justify-center text-6xl">🍽️</div>
              }
              {/* Upload overlay */}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <label className="cursor-pointer bg-white text-gray-800 px-4 py-2 rounded-xl text-xs font-bold hover:bg-amber-50 flex items-center gap-2">
                  <Icon n="upload" size={14} /> رفع صورة
                  <input type="file" accept="image/*" className="hidden" onChange={e=>uploadImg(item.id, e.target.files[0])} />
                </label>
              </div>
              {/* Tags */}
              <div className="absolute top-2 right-2 flex gap-1 flex-wrap">
                {item.is_featured === 1 && <span className="bg-amber-400 text-white text-xs px-2 py-0.5 rounded-full font-bold shadow">⭐</span>}
                {item.is_new === 1 && <span className="bg-emerald-500 text-white text-xs px-2 py-0.5 rounded-full font-bold shadow">جديد</span>}
                {item.is_spicy === 1 && <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full font-bold shadow">🌶️</span>}
                {item.is_vegetarian === 1 && <span className="bg-green-500 text-white text-xs px-2 py-0.5 rounded-full font-bold shadow">🥗</span>}
              </div>
              {!item.is_available && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <span className="bg-red-500 text-white px-4 py-2 rounded-xl font-black text-sm">غير متاح</span>
                </div>
              )}
            </div>

            <div className="p-4">
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="min-w-0">
                  <h3 className="font-black text-gray-900 leading-tight">{item.name}</h3>
                  {item.description && <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{item.description}</p>}
                </div>
                <span className="text-xl font-black text-amber-600 whitespace-nowrap">{parseFloat(item.price).toFixed(0)} ج</span>
              </div>

              <div className="flex items-center gap-3 text-xs text-gray-500 mb-3">
                <span>⏱️ {item.preparation_time_minutes} د</span>
                {item.calories && <span>🔥 {item.calories} كال</span>}
                <span className="text-amber-500 font-medium">🛒 {item.total_orders || 0}</span>
                <span className="text-gray-400">{item.category_name}</span>
              </div>

              {/* Branch availability toggles */}
              {branches.length > 0 && (
                <div className="space-y-1.5 mb-3 bg-gray-50 rounded-xl p-3">
                  <p className="text-xs font-bold text-gray-500 mb-1.5">التوفر حسب الفرع:</p>
                  {branches.map(b => {
                    const avail = item[`branch_${b.id}_available`] !== 0;
                    return (
                      <div key={b.id} className="flex items-center justify-between">
                        <span className="text-xs text-gray-600">{b.name}</span>
                        <Toggle checked={avail} onChange={()=>toggleBranch(item.id, b.id, avail)} size="sm" />
                      </div>
                    );
                  })}
                </div>
              )}

              <Btn variant="secondary" size="sm" className="w-full" onClick={()=>{ setEditItem(item); setForm({ category_id:item.category_id, name:item.name, name_en:item.name_en||"", description:item.description||"", price:item.price, preparation_time_minutes:item.preparation_time_minutes||15, calories:item.calories||"", is_available:item.is_available, is_featured:item.is_featured, is_new:item.is_new, is_spicy:item.is_spicy, is_vegetarian:item.is_vegetarian, sort_order:item.sort_order||0 }); setShowItemForm(true); }}>
                <Icon n="edit" size={14} /> تعديل
              </Btn>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-3 text-center py-20 text-gray-400">
            <div className="text-5xl mb-3">🍽️</div>
            <p className="font-medium">{search ? "لا نتائج للبحث" : "لا توجد أصناف"}</p>
          </div>
        )}
      </div>

      {/* Item Form Modal */}
      {showItemForm && (
        <Modal title={editItem ? `✏️ تعديل: ${editItem.name}` : "✨ إضافة صنف جديد"} onClose={()=>setShowItemForm(false)}>
          <div className="space-y-4">
            <Field label="القسم *">
              <Select value={form.category_id} onChange={e=>setForm({...form,category_id:e.target.value})}>
                <option value="">اختر القسم</option>
                {categories.map(c=><option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
              </Select>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="الاسم بالعربي *"><Input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} /></Field>
              <Field label="الاسم بالإنجليزي"><Input value={form.name_en} onChange={e=>setForm({...form,name_en:e.target.value})} /></Field>
            </div>
            <Field label="الوصف"><Textarea rows={2} value={form.description} onChange={e=>setForm({...form,description:e.target.value})} /></Field>
            <div className="grid grid-cols-3 gap-3">
              <Field label="السعر (ج) *"><Input type="number" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} /></Field>
              <Field label="وقت التحضير (د)"><Input type="number" value={form.preparation_time_minutes} onChange={e=>setForm({...form,preparation_time_minutes:e.target.value})} /></Field>
              <Field label="السعرات"><Input type="number" value={form.calories} onChange={e=>setForm({...form,calories:e.target.value})} /></Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[["is_available","✅ متاح"],["is_featured","⭐ مميز / الأكثر طلباً"],["is_new","🆕 جديد"],["is_spicy","🌶️ حار"],["is_vegetarian","🥗 نباتي"]].map(([k,l])=>(
                <label key={k} className="flex items-center gap-3 cursor-pointer p-3 border-2 border-gray-200 rounded-xl hover:border-amber-300 has-[:checked]:border-amber-400 has-[:checked]:bg-amber-50 transition-all">
                  <input type="checkbox" checked={!!form[k]} onChange={e=>setForm({...form,[k]:e.target.checked?1:0})} className="w-4 h-4 accent-amber-500" />
                  <span className="text-sm font-medium text-gray-700">{l}</span>
                </label>
              ))}
            </div>
            <div className="flex gap-3 pt-2">
              <Btn variant="primary" size="lg" className="flex-1" onClick={saveItem}>
                {editItem ? "💾 حفظ التعديلات" : "✅ إضافة الصنف"}
              </Btn>
              <Btn variant="secondary" onClick={()=>setShowItemForm(false)}>إلغاء</Btn>
            </div>
          </div>
        </Modal>
      )}

      {/* Category Form Modal */}
      {showCatForm && (
        <Modal title="📂 قسم جديد" onClose={()=>setShowCatForm(false)} maxW="max-w-md">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Field label="الاسم بالعربي *"><Input value={catForm.name} onChange={e=>setCatForm({...catForm,name:e.target.value})} /></Field>
              <Field label="الاسم بالإنجليزي"><Input value={catForm.name_en} onChange={e=>setCatForm({...catForm,name_en:e.target.value})} /></Field>
            </div>
            <Field label="إيموجي (أيقونة)">
              <Input value={catForm.icon} onChange={e=>setCatForm({...catForm,icon:e.target.value})} placeholder="🍖 أو 🍕 أو 🥤" />
            </Field>
            <Field label="الوصف (اختياري)"><Textarea rows={2} value={catForm.description} onChange={e=>setCatForm({...catForm,description:e.target.value})} /></Field>
            <Btn variant="primary" size="lg" className="w-full" onClick={saveCat}>✅ إضافة القسم</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════════════
// BRANCHES PAGE
// ══════════════════════════════════════════════════════════════
const BranchesPage = ({ token }) => {
  const [branches, setBranches] = useState([]);
  const [showBranchForm, setShowBranchForm] = useState(false);
  const [showZoneForm, setShowZoneForm] = useState(null);
  const [showHoursForm, setShowHoursForm] = useState(null);
  const [editBranch, setEditBranch] = useState(null);
  const [toast, setToast] = useState(null);
  const toast$ = (msg, type="success") => { setToast({msg,type}); setTimeout(()=>setToast(null),3000); };

  const emptyBranch = { name:"", address:"", phone:"", whatsapp_number:"", notification_phone:"", is_active:1 };
  const emptyZone = { zone_name:"", delivery_price:"", delivery_time_minutes:45, min_order_amount:0, notes:"", is_active:1 };
  const [bForm, setBForm] = useState(emptyBranch);
  const [zForm, setZForm] = useState(emptyZone);

  const DAYS = ["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
  const [hours, setHours] = useState(DAYS.map((_,i)=>({ day_of_week:i, open_time:"10:00", close_time:"24:00", is_closed:0 })));

  const load = async () => {
    const res = await api("GET","branches/list",null,token);
    if(res.success) setBranches(res.data||[]);
  };
  useEffect(()=>{ load(); },[]);

  const saveBranch = async () => {
    if(!bForm.name||!bForm.address) return toast$("أدخل اسم الفرع والعنوان","error");
    const res = editBranch
      ? await api("PUT",`branches/update/${editBranch.id}`,bForm,token)
      : await api("POST","branches/create",bForm,token);
    if(res.success){ toast$("✅ تم الحفظ"); setShowBranchForm(false); setEditBranch(null); load(); }
  };

  const saveZone = async () => {
    if(!zForm.zone_name||!zForm.delivery_price) return toast$("أدخل اسم المنطقة والسعر","error");
    const res = await api("POST","branches/zones",{...zForm,branch_id:showZoneForm},token);
    if(res.success){ toast$("✅ تمت إضافة المنطقة"); setShowZoneForm(null); load(); }
  };

  const updateZone = async (id, data) => {
    await api("PUT",`branches/zones/${id}`,data,token);
    load();
  };

  const saveHours = async (branchId) => {
    await api("POST","branches/working-hours",{branch_id:branchId,hours},token);
    toast$("✅ تم حفظ أوقات العمل");
    setShowHoursForm(null);
  };

  return (
    <div className="space-y-5" dir="rtl">
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={()=>setToast(null)} />}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-black text-gray-900">الفروع والمناطق 📍</h2>
        <Btn variant="primary" size="sm" onClick={()=>{ setEditBranch(null); setBForm(emptyBranch); setShowBranchForm(true); }}>
          <Icon n="plus" size={14} /> فرع جديد
        </Btn>
      </div>

      {branches.length === 0 && <div className="text-center py-16 text-gray-400"><div className="text-5xl mb-3">🏪</div><p>لا توجد فروع</p></div>}

      {branches.map(branch => (
        <div key={branch.id} className={`bg-white rounded-3xl overflow-hidden border-2 shadow-sm ${branch.is_active?"border-gray-100":"border-gray-200 opacity-70"}`}>
          {/* Branch Header */}
          <div className="p-5 flex items-center gap-4">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 ${branch.is_active?"bg-amber-100":"bg-gray-100"}`}>
              {branch.is_active ? "🏪" : "🔴"}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-black text-gray-900 text-lg">{branch.name}</h3>
              <p className="text-sm text-gray-500 truncate">{branch.address}</p>
              <div className="flex gap-4 mt-1 text-xs text-gray-400">
                {branch.phone && <span>📞 {branch.phone}</span>}
                {branch.whatsapp_number && <span>📱 {branch.whatsapp_number}</span>}
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <Btn variant="ghost" size="sm" onClick={()=>{ setEditBranch(branch); setBForm({name:branch.name,address:branch.address,phone:branch.phone||"",whatsapp_number:branch.whatsapp_number||"",notification_phone:branch.notification_phone||"",is_active:branch.is_active}); setShowBranchForm(true); }}>
                <Icon n="edit" size={14} />
              </Btn>
              <Btn variant="ghost" size="sm" onClick={()=>{ const h=branch.working_hours||DAYS.map((_,i)=>({day_of_week:i,open_time:"10:00",close_time:"24:00",is_closed:0})); setHours(h); setShowHoursForm(branch.id); }}>
                🕐
              </Btn>
              <Toggle checked={!!branch.is_active} onChange={()=>api("PUT",`branches/toggle/${branch.id}`,{},token).then(load)} />
            </div>
          </div>

          {/* Zones */}
          <div className="border-t border-gray-100 px-5 pb-5">
            <div className="flex items-center justify-between py-3">
              <span className="text-sm font-black text-gray-700">مناطق التوصيل ({branch.zones?.filter(z=>z.is_active).length||0}/{branch.zones?.length||0} نشط)</span>
              <Btn variant="secondary" size="sm" onClick={()=>{ setZForm(emptyZone); setShowZoneForm(branch.id); }}>
                <Icon n="plus" size={12} /> إضافة منطقة
              </Btn>
            </div>
            <div className="grid sm:grid-cols-2 gap-2">
              {(branch.zones||[]).map(z=>(
                <div key={z.id} className={`flex items-center justify-between p-3 rounded-xl border-2 transition-all ${z.is_active?"border-emerald-200 bg-emerald-50":"border-gray-200 bg-gray-50 opacity-60"}`}>
                  <div className="min-w-0">
                    <div className="font-bold text-gray-800 text-sm">{z.zone_name}</div>
                    <div className="text-xs text-gray-500">{parseFloat(z.delivery_price).toFixed(0)} ج | ⏱️ {z.delivery_time_minutes} د</div>
                    {z.notes && <div className="text-xs text-amber-600 mt-0.5">{z.notes}</div>}
                    {parseFloat(z.min_order_amount||0)>0 && <div className="text-xs text-gray-400">حد أدنى: {z.min_order_amount} ج</div>}
                  </div>
                  <Toggle checked={!!z.is_active} onChange={()=>updateZone(z.id,{...z,is_active:z.is_active?0:1})} size="sm" />
                </div>
              ))}
              {(!branch.zones||branch.zones.length===0) && <p className="text-gray-400 text-sm col-span-2 py-2">لا توجد مناطق توصيل بعد</p>}
            </div>
          </div>
        </div>
      ))}

      {/* Branch Form */}
      {showBranchForm && (
        <Modal title={editBranch?"✏️ تعديل الفرع":"🏪 فرع جديد"} onClose={()=>setShowBranchForm(false)} maxW="max-w-md">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Field label="اسم الفرع *"><Input value={bForm.name} onChange={e=>setBForm({...bForm,name:e.target.value})} /></Field>
              <Field label="رقم التليفون"><Input value={bForm.phone} onChange={e=>setBForm({...bForm,phone:e.target.value})} /></Field>
            </div>
            <Field label="العنوان *"><Textarea rows={2} value={bForm.address} onChange={e=>setBForm({...bForm,address:e.target.value})} /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="واتساب الفرع"><Input value={bForm.whatsapp_number} onChange={e=>setBForm({...bForm,whatsapp_number:e.target.value})} placeholder="01XXXXXXXXX" /></Field>
              <Field label="رقم الإشعارات"><Input value={bForm.notification_phone} onChange={e=>setBForm({...bForm,notification_phone:e.target.value})} placeholder="01XXXXXXXXX" /></Field>
            </div>
            <label className="flex items-center gap-3 cursor-pointer">
              <Toggle checked={!!bForm.is_active} onChange={()=>setBForm({...bForm,is_active:bForm.is_active?0:1})} />
              <span className="text-sm font-medium text-gray-700">الفرع مفتوح</span>
            </label>
            <Btn variant="primary" size="lg" className="w-full" onClick={saveBranch}>💾 حفظ الفرع</Btn>
          </div>
        </Modal>
      )}

      {/* Zone Form */}
      {showZoneForm && (
        <Modal title="📍 إضافة منطقة توصيل" onClose={()=>setShowZoneForm(null)} maxW="max-w-md">
          <div className="space-y-4">
            <Field label="اسم المنطقة *"><Input value={zForm.zone_name} onChange={e=>setZForm({...zForm,zone_name:e.target.value})} placeholder="مثال: المعادي" /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="سعر التوصيل (ج) *"><Input type="number" value={zForm.delivery_price} onChange={e=>setZForm({...zForm,delivery_price:e.target.value})} /></Field>
              <Field label="وقت التوصيل (دقيقة)"><Input type="number" value={zForm.delivery_time_minutes} onChange={e=>setZForm({...zForm,delivery_time_minutes:e.target.value})} /></Field>
            </div>
            <Field label="الحد الأدنى للطلب (ج)"><Input type="number" value={zForm.min_order_amount} onChange={e=>setZForm({...zForm,min_order_amount:e.target.value})} /></Field>
            <Field label="ملاحظة (اختياري)"><Input value={zForm.notes} onChange={e=>setZForm({...zForm,notes:e.target.value})} placeholder="مثال: توصيل بعد 6 مساءً فقط" /></Field>
            <Btn variant="primary" size="lg" className="w-full" onClick={saveZone}>✅ إضافة المنطقة</Btn>
          </div>
        </Modal>
      )}

      {/* Working Hours Form */}
      {showHoursForm && (
        <Modal title="🕐 أوقات العمل" onClose={()=>setShowHoursForm(null)}>
          <div className="space-y-3">
            {hours.map((h,i)=>(
              <div key={i} className={`flex items-center gap-3 p-3 rounded-xl border-2 transition-all ${h.is_closed?"border-gray-200 bg-gray-50 opacity-70":"border-amber-200 bg-amber-50/50"}`}>
                <span className="w-16 text-sm font-bold text-gray-700 flex-shrink-0">{DAYS[i]}</span>
                <Toggle checked={!h.is_closed} onChange={()=>setHours(prev=>prev.map((d,j)=>j===i?{...d,is_closed:d.is_closed?0:1}:d))} size="sm" />
                {!h.is_closed && (
                  <>
                    <Input type="time" value={h.open_time} onChange={e=>setHours(prev=>prev.map((d,j)=>j===i?{...d,open_time:e.target.value}:d))} className="flex-1 text-xs py-1.5" />
                    <span className="text-gray-400 text-xs">إلى</span>
                    <Input type="time" value={h.close_time} onChange={e=>setHours(prev=>prev.map((d,j)=>j===i?{...d,close_time:e.target.value}:d))} className="flex-1 text-xs py-1.5" />
                  </>
                )}
                {h.is_closed && <span className="text-xs text-gray-400 flex-1">مغلق</span>}
              </div>
            ))}
            <Btn variant="primary" size="lg" className="w-full mt-2" onClick={()=>saveHours(showHoursForm)}>💾 حفظ الأوقات</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════════════
// CUSTOMERS PAGE
// ══════════════════════════════════════════════════════════════
const CustomersPage = ({ token }) => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [toast, setToast] = useState(null);
  const toast$ = (msg, type="success") => { setToast({msg,type}); setTimeout(()=>setToast(null),3000); };

  const load = async (q="") => {
    setLoading(true);
    const res = await api("GET",`customers/list${q?`?search=${encodeURIComponent(q)}`:""}`,null,token);
    if(res.success) setCustomers(res.data||[]);
    setLoading(false);
  };
  useEffect(()=>{ load(); },[]);

  const toggleBlacklist = async (c) => {
    const newVal = c.is_blacklisted ? 0 : 1;
    const reason = newVal ? prompt("سبب الحظر؟") : null;
    if(newVal && !reason) return;
    await api("PUT",`customers/blacklist/${c.id}`,{is_blacklisted:newVal,reason},token);
    toast$(newVal?"تم حظر العميل":"تم رفع الحظر");
    load(search);
    if(selected?.id===c.id) setSelected({...selected,is_blacklisted:newVal});
  };

  return (
    <div className="space-y-4" dir="rtl">
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={()=>setToast(null)} />}
      <h2 className="text-2xl font-black text-gray-900">العملاء 👥</h2>

      <div className="relative">
        <Input value={search} onChange={e=>setSearch(e.target.value)} onKeyDown={e=>e.key==="Enter"&&load(search)} placeholder="ابحث بالاسم أو رقم الواتساب..." className="pr-10" />
        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"><Icon n="search" size={16} /></span>
      </div>

      {loading ? <Spinner /> : (
        <div className="space-y-2">
          {customers.length === 0 && <div className="text-center py-16 text-gray-400"><div className="text-5xl mb-3">👥</div><p>لا يوجد عملاء</p></div>}
          {customers.map(c=>(
            <div key={c.id} onClick={()=>setSelected(c)}
              className={`bg-white rounded-2xl p-4 border-2 cursor-pointer hover:shadow-md transition-all flex items-center gap-4 ${c.is_blacklisted?"border-red-200 bg-red-50/30 opacity-70":"border-gray-100 hover:border-amber-200"}`}>
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl flex-shrink-0 ${c.is_blacklisted?"bg-red-100":"bg-amber-100"}`}>
                {c.is_blacklisted ? "🚫" : "👤"}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-gray-900">{c.name || "بدون اسم"}</span>
                  {c.is_blacklisted && <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-bold">محظور</span>}
                </div>
                <div className="text-sm text-gray-500">{c.whatsapp_number}</div>
                <div className="text-xs text-gray-400 mt-0.5">
                  {c.total_orders||0} طلب | {parseFloat(c.total_spent||0).toFixed(0)} ج إجمالي
                  {c.last_order_at && ` | آخر طلب: ${new Date(c.last_order_at).toLocaleDateString('ar-EG')}`}
                </div>
              </div>
              <Btn variant={c.is_blacklisted?"success":"danger"} size="sm" onClick={e=>{e.stopPropagation();toggleBlacklist(c);}}>
                {c.is_blacklisted ? "رفع الحظر" : <><Icon n="ban" size={12}/> حظر</>}
              </Btn>
            </div>
          ))}
        </div>
      )}

      {selected && (
        <Modal title={`👤 ${selected.name || selected.whatsapp_number}`} onClose={()=>setSelected(null)}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              {[
                ["واتساب", selected.whatsapp_number],
                ["الاسم", selected.name||"—"],
                ["تليفون", selected.phone||"—"],
                ["إيميل", selected.email||"—"],
                ["إجمالي الطلبات", selected.total_orders||0],
                ["إجمالي الإنفاق", `${parseFloat(selected.total_spent||0).toFixed(0)} ج`],
              ].map(([l,v])=>(
                <div key={l} className="bg-gray-50 rounded-xl p-3">
                  <div className="text-xs text-gray-400 font-medium mb-0.5">{l}</div>
                  <div className="font-bold text-gray-800 text-sm">{v}</div>
                </div>
              ))}
            </div>
            {selected.notes && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-3 text-sm">
                <span className="font-bold text-yellow-800">📝 ملاحظات: </span>
                <span className="text-yellow-700">{selected.notes}</span>
              </div>
            )}
            {selected.blacklist_reason && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-sm">
                <span className="font-bold text-red-800">🚫 سبب الحظر: </span>
                <span className="text-red-700">{selected.blacklist_reason}</span>
              </div>
            )}
            <Btn variant={selected.is_blacklisted?"success":"danger"} size="lg" className="w-full" onClick={()=>toggleBlacklist(selected)}>
              {selected.is_blacklisted ? "✅ رفع الحظر" : "🚫 حظر العميل"}
            </Btn>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════════════
// COUPONS PAGE
// ══════════════════════════════════════════════════════════════
const CouponsPage = ({ token }) => {
  const [coupons, setCoupons] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [toast, setToast] = useState(null);
  const toast$ = (msg, type="success") => { setToast({msg,type}); setTimeout(()=>setToast(null),3000); };
  const emptyForm = { code:"", description:"", type:"percentage", value:"", min_order_amount:0, max_discount:"", usage_limit:"", usage_per_customer:1, valid_from:"", valid_until:"" };
  const [form, setForm] = useState(emptyForm);

  const load = async () => { const res=await api("GET","coupons/list",null,token); if(res.success) setCoupons(res.data||[]); };
  useEffect(()=>{ load(); },[]);

  const save = async () => {
    if(!form.code||!form.value) return toast$("أدخل الكود والقيمة","error");
    const res = await api("POST","coupons/create",{...form,code:form.code.toUpperCase()},token);
    if(res.success){ toast$("✅ تم إنشاء الكوبون"); setShowForm(false); load(); }
    else toast$(res.message||"حدث خطأ","error");
  };

  return (
    <div className="space-y-4" dir="rtl">
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={()=>setToast(null)} />}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-black text-gray-900">الكوبونات 🎫</h2>
        <Btn variant="primary" size="sm" onClick={()=>{ setForm(emptyForm); setShowForm(true); }}>
          <Icon n="plus" size={14} /> كوبون جديد
        </Btn>
      </div>

      <div className="space-y-3">
        {coupons.length === 0 && <div className="text-center py-16 text-gray-400"><div className="text-5xl mb-3">🎫</div><p>لا توجد كوبونات</p></div>}
        {coupons.map(c=>(
          <div key={c.id} className={`bg-white rounded-2xl p-5 border-2 flex items-center gap-4 ${c.is_active?"border-amber-200":"border-gray-200 opacity-60"}`}>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-2xl px-5 py-3 text-center flex-shrink-0">
              <div className="font-black text-amber-700 text-lg tracking-widest">{c.code}</div>
              <div className="text-xs text-amber-600 font-bold mt-0.5">
                {c.type==="percentage"?`${c.value}% خصم`:`${c.value} ج خصم`}
              </div>
            </div>
            <div className="flex-1 min-w-0">
              {c.description && <div className="font-semibold text-gray-800 text-sm">{c.description}</div>}
              <div className="text-xs text-gray-500 mt-1 space-y-0.5">
                {parseFloat(c.min_order_amount)>0 && <div>حد أدنى: {c.min_order_amount} ج</div>}
                {c.max_discount && <div>حد أقصى للخصم: {c.max_discount} ج</div>}
                <div>استُخدم {c.used_count} مرة {c.usage_limit?`من ${c.usage_limit}`:""}</div>
                {c.valid_until && <div>ينتهي: {new Date(c.valid_until).toLocaleDateString('ar-EG')}</div>}
              </div>
            </div>
            <div className="flex items-center gap-3 flex-shrink-0">
              <Toggle checked={!!c.is_active} onChange={()=>api("PUT",`coupons/toggle/${c.id}`,{},token).then(load)} size="sm" />
              <Btn variant="ghost" size="sm" onClick={()=>api("DELETE",`coupons/delete/${c.id}`,{},token).then(load)}>
                <Icon n="trash" size={14} />
              </Btn>
            </div>
          </div>
        ))}
      </div>

      {showForm && (
        <Modal title="🎫 كوبون جديد" onClose={()=>setShowForm(false)} maxW="max-w-md">
          <div className="space-y-4">
            <Field label="كود الكوبون *">
              <Input value={form.code} onChange={e=>setForm({...form,code:e.target.value.toUpperCase()})} placeholder="SUMMER25" className="font-mono tracking-widest text-amber-700 font-bold" />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="نوع الخصم">
                <Select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>
                  <option value="percentage">نسبة مئوية %</option>
                  <option value="fixed">مبلغ ثابت</option>
                </Select>
              </Field>
              <Field label={form.type==="percentage"?"نسبة الخصم % *":"مبلغ الخصم ج *"}>
                <Input type="number" value={form.value} onChange={e=>setForm({...form,value:e.target.value})} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="الحد الأدنى للطلب (ج)"><Input type="number" value={form.min_order_amount} onChange={e=>setForm({...form,min_order_amount:e.target.value})} /></Field>
              <Field label="حد أقصى للخصم (ج)"><Input type="number" value={form.max_discount} onChange={e=>setForm({...form,max_discount:e.target.value})} placeholder="اختياري" /></Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="عدد مرات الاستخدام"><Input type="number" value={form.usage_limit} onChange={e=>setForm({...form,usage_limit:e.target.value})} placeholder="غير محدود" /></Field>
              <Field label="مرات لكل عميل"><Input type="number" value={form.usage_per_customer} onChange={e=>setForm({...form,usage_per_customer:e.target.value})} /></Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="تاريخ البداية"><Input type="datetime-local" value={form.valid_from} onChange={e=>setForm({...form,valid_from:e.target.value})} /></Field>
              <Field label="تاريخ الانتهاء"><Input type="datetime-local" value={form.valid_until} onChange={e=>setForm({...form,valid_until:e.target.value})} /></Field>
            </div>
            <Field label="وصف (اختياري)"><Input value={form.description} onChange={e=>setForm({...form,description:e.target.value})} /></Field>
            <Btn variant="primary" size="lg" className="w-full" onClick={save}>✅ إنشاء الكوبون</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════════════
// SETTINGS PAGE
// ══════════════════════════════════════════════════════════════
const SettingsPage = ({ token }) => {
  const [settings, setSettings] = useState(null);
  const [form, setForm] = useState({});
  const [toast, setToast] = useState(null);
  const [tab, setTab] = useState("general");
  const [faqs, setFaqs] = useState([]);
  const [faqForm, setFaqForm] = useState({ question:"", answer:"", category:"general" });
  const [showFaqForm, setShowFaqForm] = useState(false);
  const toast$ = (msg, type="success") => { setToast({msg,type}); setTimeout(()=>setToast(null),3000); };

  useEffect(()=>{
    api("GET","settings/get",null,token).then(r=>{ if(r.success){ setSettings(r.data); setForm(r.data); } });
    api("GET","settings/faq",null,token).then(r=>{ if(r.success) setFaqs(r.data||[]); });
  },[]);

  const save = async () => {
    const res = await api("PUT","settings/update",form,token);
    if(res.success){ toast$("✅ تم حفظ الإعدادات"); }
    else toast$(res.message||"حدث خطأ","error");
  };

  const toggle = async (field) => {
    const ep = field==="is_open"?"settings/toggle-open":"settings/toggle-orders";
    const res = await api("PUT",ep,{},token);
    if(res.success){
      const key = Object.keys(res.data)[0];
      setForm(p=>({...p,[key]:res.data[key]}));
      toast$(res.data[key] ? (field==="is_open"?"🟢 المطعم الآن مفتوح":"⚠️ الطلبات موقوفة") : (field==="is_open"?"🔴 المطعم الآن مغلق":"✅ الطلبات تعمل"));
    }
  };

  const addFaq = async () => {
    if(!faqForm.question||!faqForm.answer) return toast$("أكمل السؤال والجواب","error");
    const res = await api("POST","settings/faq",faqForm,token);
    if(res.success){ toast$("✅ تمت الإضافة"); setShowFaqForm(false); api("GET","settings/faq",null,token).then(r=>r.success&&setFaqs(r.data||[])); }
  };

  const tabs = [
    {k:"general",l:"⚙️ عام"},
    {k:"bot",l:"🤖 البوت"},
    {k:"toggles",l:"🔴 التحكم السريع"},
    {k:"faq",l:"❓ أسئلة البوت"},
  ];

  if(!settings) return <Spinner />;

  return (
    <div className="space-y-5 max-w-2xl" dir="rtl">
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={()=>setToast(null)} />}
      <h2 className="text-2xl font-black text-gray-900">الإعدادات ⚙️</h2>

      {/* Tab Bar */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {tabs.map(t=>(
          <button key={t.k} onClick={()=>setTab(t.k)}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex-shrink-0 border-2 transition-all ${tab===t.k?"bg-amber-500 text-white border-amber-500":"bg-white border-gray-200 text-gray-600 hover:border-amber-300"}`}>
            {t.l}
          </button>
        ))}
      </div>

      {/* Quick Control */}
      {tab==="toggles" && (
        <div className="space-y-4">
          {[
            { field:"is_open", label:"حالة المطعم", onLabel:"🟢 مفتوح الآن", offLabel:"🔴 مغلق الآن", onColor:"bg-emerald-50 border-emerald-200", offColor:"bg-red-50 border-red-200" },
            { field:"orders_paused", label:"الطلبات", onLabel:"⚠️ الطلبات موقوفة مؤقتاً", offLabel:"✅ الطلبات تعمل", onColor:"bg-orange-50 border-orange-200", offColor:"bg-emerald-50 border-emerald-200", invert:true },
          ].map(item=>{
            const active = item.invert ? !!form[item.field] : !!form[item.field];
            const isGood = item.invert ? !active : active;
            return (
              <div key={item.field} className={`bg-white rounded-2xl p-6 border-2 flex items-center justify-between ${isGood?"border-emerald-200":"border-red-200"}`}>
                <div>
                  <div className="font-black text-gray-800 mb-1">{item.label}</div>
                  <div className={`text-sm font-bold ${isGood?"text-emerald-600":"text-red-500"}`}>
                    {item.invert ? (active?item.onLabel:item.offLabel) : (active?item.onLabel:item.offLabel)}
                  </div>
                </div>
                <Toggle checked={active} onChange={()=>toggle(item.field)} />
              </div>
            );
          })}
          <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-sm text-blue-700">
            💡 عند إغلاق المطعم، البوت يرد برسالة الإغلاق تلقائياً ولا يقبل طلبات.
          </div>
        </div>
      )}

      {/* General Settings */}
      {tab==="general" && (
        <div className="bg-white rounded-2xl p-6 border border-gray-100 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="اسم المطعم *"><Input value={form.name||""} onChange={e=>setForm({...form,name:e.target.value})} /></Field>
            <Field label="العملة"><Input value={form.currency||"جنيه"} onChange={e=>setForm({...form,currency:e.target.value})} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="التليفون"><Input value={form.phone||""} onChange={e=>setForm({...form,phone:e.target.value})} /></Field>
            <Field label="البريد الإلكتروني"><Input value={form.email||""} onChange={e=>setForm({...form,email:e.target.value})} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="الحد الأدنى للطلب (ج)"><Input type="number" value={form.min_order_amount||0} onChange={e=>setForm({...form,min_order_amount:e.target.value})} /></Field>
            <Field label="نسبة الضريبة %"><Input type="number" value={form.tax_percentage||0} onChange={e=>setForm({...form,tax_percentage:e.target.value})} /></Field>
          </div>
          <Field label="رسالة الإغلاق">
            <Input value={form.closed_message||""} onChange={e=>setForm({...form,closed_message:e.target.value})} placeholder="المطعم مغلق حالياً..." />
          </Field>
          <Field label="رسالة إيقاف الطلبات">
            <Input value={form.paused_message||""} onChange={e=>setForm({...form,paused_message:e.target.value})} placeholder="الطلبات متوقفة مؤقتاً..." />
          </Field>
          <div className="grid grid-cols-3 gap-3">
            <Field label="فيسبوك"><Input value={form.facebook||""} onChange={e=>setForm({...form,facebook:e.target.value})} /></Field>
            <Field label="انستجرام"><Input value={form.instagram||""} onChange={e=>setForm({...form,instagram:e.target.value})} /></Field>
            <Field label="الموقع"><Input value={form.website||""} onChange={e=>setForm({...form,website:e.target.value})} /></Field>
          </div>
          <Btn variant="primary" size="lg" className="w-full" onClick={save}>💾 حفظ الإعدادات</Btn>
        </div>
      )}

      {/* Bot Settings */}
      {tab==="bot" && (
        <div className="bg-white rounded-2xl p-6 border border-gray-100 space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
            🤖 هذه الإعدادات تتحكم في شخصية وسلوك الـ AI Agent. التعديلات هنا تؤثر مباشرة على ردود البوت.
          </div>
          <Field label="اسم البوت (اسم المساعد)">
            <Input value={form.bot_name||"نور"} onChange={e=>setForm({...form,bot_name:e.target.value})} placeholder="نور" />
          </Field>
          <Field label="رسالة الترحيب (أول رسالة للعميل)">
            <Textarea rows={3} value={form.welcome_message||""} onChange={e=>setForm({...form,welcome_message:e.target.value})} />
          </Field>
          <Field label="شخصية البوت وتعليماته (System Prompt)">
            <Textarea rows={6} value={form.bot_personality||""} onChange={e=>setForm({...form,bot_personality:e.target.value})} placeholder="أكتب كيف تريد البوت أن يتصرف ويتكلم..." />
          </Field>
          <Btn variant="primary" size="lg" className="w-full" onClick={save}>💾 حفظ إعدادات البوت</Btn>
        </div>
      )}

      {/* FAQ for Bot */}
      {tab==="faq" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-500">الأسئلة الشائعة تساعد البوت يجاوب بشكل صحيح</p>
            <Btn variant="primary" size="sm" onClick={()=>{ setFaqForm({question:"",answer:"",category:"general"}); setShowFaqForm(true); }}>
              <Icon n="plus" size={14} /> سؤال جديد
            </Btn>
          </div>
          <div className="space-y-3">
            {faqs.map((f,i)=>(
              <div key={i} className="bg-white rounded-2xl p-4 border border-gray-100">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-gray-800 text-sm">❓ {f.question}</p>
                    <p className="text-gray-600 text-sm mt-1 leading-relaxed">✅ {f.answer}</p>
                  </div>
                  <Btn variant="danger" size="sm" onClick={()=>api("DELETE",`settings/faq/${f.id}`,{},token).then(()=>api("GET","settings/faq",null,token).then(r=>r.success&&setFaqs(r.data||[])))}>
                    <Icon n="trash" size={12} />
                  </Btn>
                </div>
              </div>
            ))}
            {faqs.length===0 && <div className="text-center py-8 text-gray-400 text-sm">لا أسئلة بعد. أضف أسئلة شائعة يسألها عملاؤك.</div>}
          </div>

          {showFaqForm && (
            <Modal title="❓ سؤال جديد" onClose={()=>setShowFaqForm(false)} maxW="max-w-md">
              <div className="space-y-4">
                <Field label="السؤال *"><Input value={faqForm.question} onChange={e=>setFaqForm({...faqForm,question:e.target.value})} placeholder="مثال: ما أوقات عملكم؟" /></Field>
                <Field label="الجواب *"><Textarea rows={3} value={faqForm.answer} onChange={e=>setFaqForm({...faqForm,answer:e.target.value})} placeholder="الجواب الذي سيقوله البوت..." /></Field>
                <Field label="التصنيف">
                  <Select value={faqForm.category} onChange={e=>setFaqForm({...faqForm,category:e.target.value})}>
                    <option value="general">عام</option>
                    <option value="delivery">توصيل</option>
                    <option value="payment">دفع</option>
                    <option value="menu">منيو</option>
                  </Select>
                </Field>
                <Btn variant="primary" size="lg" className="w-full" onClick={addFaq}>✅ إضافة السؤال</Btn>
              </div>
            </Modal>
          )}
        </div>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════════════
// OFFERS PAGE
// ══════════════════════════════════════════════════════════════
const OffersPage = ({ token }) => {
  const [offers, setOffers] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editOffer, setEditOffer] = useState(null);
  const [toast, setToast] = useState(null);
  const toast$ = (msg, type="success") => { setToast({msg,type}); setTimeout(()=>setToast(null),3000); };

  const emptyForm = { name:"", description:"", type:"combo", price:"", valid_from:"", valid_until:"", items:[] };
  const [form, setForm] = useState(emptyForm);
  const [selectedItem, setSelectedItem] = useState("");
  const [selectedQty, setSelectedQty] = useState(1);

  const load = async () => {
    const [o, m] = await Promise.all([
      api("GET","offers/list",null,token),
      api("GET","menu/items",null,token),
    ]);
    if(o.success) setOffers(o.data||[]);
    if(m.success) setMenuItems(m.data||[]);
  };
  useEffect(()=>{ load(); },[]);

  const addItemToForm = () => {
    if(!selectedItem) return;
    const item = menuItems.find(m=>m.id==selectedItem);
    if(!item) return;
    if(form.items.find(i=>i.item_id==selectedItem)) return toast$("الصنف مضاف بالفعل","error");
    setForm(p=>({...p, items:[...p.items,{item_id:item.id, item_name:item.name, price:item.price, quantity:selectedQty}]}));
    setSelectedItem(""); setSelectedQty(1);
  };

  const save = async () => {
    if(!form.name) return toast$("أدخل اسم الأوفر","error");
    const res = editOffer
      ? await api("PUT",`offers/update/${editOffer.id}`,form,token)
      : await api("POST","offers/create",form,token);
    if(res.success){ toast$(editOffer?"✅ تم التحديث":"✅ تم إنشاء الأوفر"); setShowForm(false); setEditOffer(null); load(); }
    else toast$(res.message||"حدث خطأ","error");
  };

  const totalPrice = form.items.reduce((s,i)=>s+parseFloat(i.price||0)*i.quantity,0);

  return (
    <div className="space-y-4" dir="rtl">
      {toast && <Toast msg={toast.msg} type={toast.type} onClose={()=>setToast(null)} />}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-black text-gray-900">الأوفر والعروض 🎁</h2>
        <Btn variant="primary" size="sm" onClick={()=>{ setEditOffer(null); setForm(emptyForm); setShowForm(true); }}>
          <Icon n="plus" size={14}/> أوفر جديد
        </Btn>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {offers.length===0 && <div className="col-span-3 text-center py-16 text-gray-400"><div className="text-5xl mb-3">🎁</div><p>لا توجد عروض</p></div>}
        {offers.map(offer=>(
          <div key={offer.id} className={`bg-white rounded-2xl overflow-hidden border-2 shadow-sm hover:shadow-md transition-all ${offer.is_active?"border-amber-200":"border-gray-200 opacity-60"}`}>
            {offer.image
              ? <img src={offer.image} alt={offer.name} className="w-full h-36 object-cover"/>
              : <div className="w-full h-36 bg-gradient-to-br from-amber-100 to-orange-100 flex items-center justify-center text-5xl">🎁</div>
            }
            <div className="p-4">
              <h3 className="font-black text-gray-900 mb-1">{offer.name}</h3>
              {offer.description && <p className="text-xs text-gray-500 mb-2 line-clamp-2">{offer.description}</p>}
              {offer.price && <div className="text-lg font-black text-amber-600 mb-2">{parseFloat(offer.price).toFixed(0)} ج</div>}
              {(offer.items||[]).length>0 && (
                <div className="bg-gray-50 rounded-xl p-2 mb-3 space-y-1">
                  {offer.items.map((it,i)=>(
                    <div key={i} className="text-xs text-gray-600 flex justify-between">
                      <span>{it.quantity}× {it.item_name}</span>
                      <span className="text-gray-400">{parseFloat(it.price||0).toFixed(0)} ج</span>
                    </div>
                  ))}
                </div>
              )}
              {offer.valid_until && (
                <div className="text-xs text-orange-500 mb-3">⏳ ينتهي: {new Date(offer.valid_until).toLocaleDateString('ar-EG')}</div>
              )}
              <div className="flex items-center justify-between">
                <Toggle checked={!!offer.is_active} onChange={()=>api("PUT",`offers/toggle/${offer.id}`,{},token).then(load)} size="sm"/>
                <div className="flex gap-2">
                  <Btn variant="secondary" size="sm" onClick={()=>{ setEditOffer(offer); setForm({name:offer.name,description:offer.description||"",type:offer.type,price:offer.price||"",valid_from:offer.valid_from||"",valid_until:offer.valid_until||"",items:(offer.items||[]).map(i=>({item_id:i.item_id||i.id,item_name:i.item_name,price:i.price,quantity:i.quantity}))}); setShowForm(true); }}>
                    <Icon n="edit" size={13}/>
                  </Btn>
                  <Btn variant="danger" size="sm" onClick={()=>api("DELETE",`offers/delete/${offer.id}`,{},token).then(load)}>
                    <Icon n="trash" size={13}/>
                  </Btn>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showForm && (
        <Modal title={editOffer?"✏️ تعديل الأوفر":"🎁 أوفر جديد"} onClose={()=>setShowForm(false)}>
          <div className="space-y-4">
            <Field label="اسم الأوفر *"><Input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="مثال: وجبة عيلة" /></Field>
            <Field label="الوصف"><Textarea rows={2} value={form.description} onChange={e=>setForm({...form,description:e.target.value})} /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="النوع">
                <Select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>
                  <option value="combo">كومبو</option>
                  <option value="discount">خصم</option>
                  <option value="free_item">صنف مجاني</option>
                </Select>
              </Field>
              <Field label="سعر الأوفر (ج)"><Input type="number" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} placeholder="اتركه فارغ لو بدون سعر" /></Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="تاريخ البداية"><Input type="datetime-local" value={form.valid_from} onChange={e=>setForm({...form,valid_from:e.target.value})} /></Field>
              <Field label="تاريخ الانتهاء"><Input type="datetime-local" value={form.valid_until} onChange={e=>setForm({...form,valid_until:e.target.value})} /></Field>
            </div>

            {/* Add items */}
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 space-y-3">
              <p className="font-bold text-amber-800 text-sm">أصناف الأوفر</p>
              <div className="flex gap-2">
                <Select value={selectedItem} onChange={e=>setSelectedItem(e.target.value)} className="flex-1">
                  <option value="">اختر صنف</option>
                  {menuItems.map(m=><option key={m.id} value={m.id}>{m.name} — {parseFloat(m.price).toFixed(0)} ج</option>)}
                </Select>
                <Input type="number" value={selectedQty} onChange={e=>setSelectedQty(parseInt(e.target.value)||1)} className="w-16" min={1}/>
                <Btn variant="primary" size="sm" onClick={addItemToForm}>+</Btn>
              </div>
              {form.items.length>0 && (
                <div className="space-y-2">
                  {form.items.map((it,i)=>(
                    <div key={i} className="flex items-center justify-between bg-white rounded-xl p-2.5 text-sm">
                      <span className="font-medium text-gray-700">{it.quantity}× {it.item_name}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-amber-600 font-bold">{parseFloat(it.price||0)*it.quantity} ج</span>
                        <button onClick={()=>setForm(p=>({...p,items:p.items.filter((_,j)=>j!==i)}))} className="text-red-400 hover:text-red-600">×</button>
                      </div>
                    </div>
                  ))}
                  <div className="flex justify-between text-sm font-black text-gray-800 pt-1 border-t border-amber-200">
                    <span>السعر الأصلي</span><span>{totalPrice.toFixed(0)} ج</span>
                  </div>
                  {form.price && <div className="flex justify-between text-sm font-black text-emerald-600">
                    <span>توفير العميل</span><span>{(totalPrice-parseFloat(form.price)).toFixed(0)} ج</span>
                  </div>}
                </div>
              )}
            </div>

            <Btn variant="primary" size="lg" className="w-full" onClick={save}>
              {editOffer?"💾 حفظ التعديلات":"✅ إنشاء الأوفر"}
            </Btn>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════════════
// REPORTS PAGE
// ══════════════════════════════════════════════════════════════
const ReportsPage = ({ token }) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [from, setFrom] = useState(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split("T")[0]);
  const [to, setTo] = useState(new Date().toISOString().split("T")[0]);
  const [ratings, setRatings] = useState(null);

  const load = async () => {
    setLoading(true);
    const [r, rat] = await Promise.all([
      api("GET",`reports/sales?from=${from}&to=${to}`,null,token),
      api("GET","reports/ratings",null,token),
    ]);
    if(r.success) setData(r.data);
    if(rat.success) setRatings(rat.data);
    setLoading(false);
  };
  useEffect(()=>{ load(); },[]);

  const exportCSV = () => window.open(`${API_BASE}/reports/export-csv?from=${from}&to=${to}&token=${token}`);

  const t = data?.totals || {};
  const summaryCards = [
    { l:"إجمالي الطلبات", v:t.total_orders||0, icon:"📦", c:"from-blue-500 to-blue-600" },
    { l:"الإيرادات", v:`${parseFloat(t.total_revenue||0).toFixed(0)} ج`, icon:"💰", c:"from-emerald-500 to-emerald-600" },
    { l:"دخل التوصيل", v:`${parseFloat(t.total_delivery||0).toFixed(0)} ج`, icon:"🛵", c:"from-orange-500 to-orange-600" },
    { l:"إجمالي الخصومات", v:`${parseFloat(t.total_discounts||0).toFixed(0)} ج`, icon:"🏷️", c:"from-red-500 to-red-600" },
    { l:"متوسط الطلب", v:`${parseFloat(t.avg_order||0).toFixed(0)} ج`, icon:"📊", c:"from-purple-500 to-purple-600" },
    { l:"عملاء جدد", v:data?.customers?.new_customers||0, icon:"👥", c:"from-teal-500 to-teal-600" },
  ];

  return (
    <div className="space-y-5" dir="rtl">
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <h2 className="text-2xl font-black text-gray-900">التقارير 📈</h2>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-gray-500">من</span>
            <Input type="date" value={from} onChange={e=>setFrom(e.target.value)} className="w-36 text-sm" />
            <span className="text-gray-500">إلى</span>
            <Input type="date" value={to} onChange={e=>setTo(e.target.value)} className="w-36 text-sm" />
          </div>
          <Btn variant="primary" size="sm" onClick={load} disabled={loading}>{loading?"⏳ جاري...":"🔍 عرض"}</Btn>
          <Btn variant="secondary" size="sm" onClick={exportCSV}>📥 تصدير CSV</Btn>
        </div>
      </div>

      {loading && <Spinner />}

      {!loading && data && (
        <>
          {/* Summary cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {summaryCards.map((c,i)=>(
              <div key={i} className={`bg-gradient-to-br ${c.c} rounded-2xl p-5 text-white shadow-lg`}>
                <div className="text-3xl mb-2">{c.icon}</div>
                <div className="text-2xl font-black">{c.v}</div>
                <div className="text-white/80 text-xs mt-1">{c.l}</div>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-5">
            {/* Top Items */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <h3 className="font-black text-gray-800 mb-4">🔥 أكثر الأصناف طلباً</h3>
              <div className="space-y-3">
                {(data.top_items||[]).map((item,i)=>(
                  <div key={i} className="flex items-center gap-3">
                    <span className={`w-7 h-7 rounded-lg text-xs font-black text-white flex items-center justify-center flex-shrink-0 ${["bg-amber-400","bg-gray-400","bg-orange-400","bg-teal-400","bg-blue-400","bg-purple-400","bg-pink-400","bg-red-400","bg-indigo-400","bg-green-400"][i]||"bg-gray-300"}`}>{i+1}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-gray-800 truncate">{item.item_name}</div>
                      <div className="w-full bg-gray-100 rounded-full h-1.5 mt-1">
                        <div className="bg-amber-400 h-1.5 rounded-full transition-all" style={{width:`${Math.min(100,(item.total_qty/(data.top_items[0]?.total_qty||1))*100)}%`}}/>
                      </div>
                    </div>
                    <div className="text-right text-xs flex-shrink-0">
                      <div className="font-black text-gray-800">{item.total_qty} طلب</div>
                      <div className="text-gray-500">{parseFloat(item.revenue||0).toFixed(0)} ج</div>
                    </div>
                  </div>
                ))}
                {(data.top_items||[]).length===0 && <p className="text-gray-400 text-sm text-center py-4">لا بيانات</p>}
              </div>
            </div>

            {/* Top Categories */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <h3 className="font-black text-gray-800 mb-4">📂 الأقسام الأكثر مبيعاً</h3>
              <div className="space-y-3">
                {(data.top_cats||[]).map((cat,i)=>(
                  <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                    <span className="font-semibold text-gray-700 text-sm">{cat.category}</span>
                    <div className="text-right text-xs">
                      <div className="font-black text-amber-600">{parseFloat(cat.revenue||0).toFixed(0)} ج</div>
                      <div className="text-gray-500">{cat.total_qty} قطعة</div>
                    </div>
                  </div>
                ))}
                {(data.top_cats||[]).length===0 && <p className="text-gray-400 text-sm text-center py-4">لا بيانات</p>}
              </div>
            </div>

            {/* Daily trend */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <h3 className="font-black text-gray-800 mb-4">📅 المبيعات اليومية</h3>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {(data.daily||[]).map((d,i)=>(
                  <div key={i} className="flex items-center justify-between text-sm p-2 rounded-xl hover:bg-gray-50">
                    <span className="text-gray-600 font-medium">{new Date(d.date).toLocaleDateString('ar-EG',{weekday:'short',month:'short',day:'numeric'})}</span>
                    <div className="flex items-center gap-4 text-xs">
                      <span className="text-gray-500">{d.orders} طلب</span>
                      <span className="font-black text-emerald-600">{parseFloat(d.revenue||0).toFixed(0)} ج</span>
                    </div>
                  </div>
                ))}
                {(data.daily||[]).length===0 && <p className="text-gray-400 text-sm text-center py-4">لا بيانات في هذه الفترة</p>}
              </div>
            </div>

            {/* Ratings */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <h3 className="font-black text-gray-800 mb-1">⭐ التقييمات</h3>
              {ratings?.summary && (
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-4xl font-black text-amber-500">{parseFloat(ratings.summary.avg||0).toFixed(1)}</span>
                  <div>
                    <div className="text-amber-400 text-xl">{"★".repeat(Math.round(ratings.summary.avg||0))}{"☆".repeat(5-Math.round(ratings.summary.avg||0))}</div>
                    <div className="text-xs text-gray-500">{ratings.summary.total} تقييم</div>
                  </div>
                </div>
              )}
              <div className="space-y-2">
                {([5,4,3,2,1]).map(star=>{
                  const r = ratings?.ratings?.find(x=>x.rating==star);
                  return (
                    <div key={star} className="flex items-center gap-2 text-sm">
                      <span className="text-amber-400 w-16 text-xs">{"★".repeat(star)}</span>
                      <div className="flex-1 bg-gray-100 rounded-full h-2">
                        <div className="bg-amber-400 h-2 rounded-full transition-all" style={{width:`${r?.pct||0}%`}}/>
                      </div>
                      <span className="text-xs text-gray-500 w-10 text-left">{r?.count||0}</span>
                    </div>
                  );
                })}
              </div>

              {/* Zone performance */}
              {(data.zones||[]).length>0 && (
                <>
                  <h4 className="font-black text-gray-700 mt-5 mb-3 text-sm">📍 أداء المناطق</h4>
                  <div className="space-y-2">
                    {data.zones.slice(0,5).map((z,i)=>(
                      <div key={i} className="flex justify-between text-xs p-2 bg-gray-50 rounded-lg">
                        <span className="text-gray-700 font-medium">{z.zone_name} <span className="text-gray-400">— {z.branch}</span></span>
                        <span className="font-bold text-amber-600">{z.orders} طلب</span>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════════════
// MAIN APP
// ══════════════════════════════════════════════════════════════
export default function App() {
  const [token, setToken] = useState(()=>localStorage.getItem("rtoken"));
  const [user, setUser] = useState(()=>{ try{ return JSON.parse(localStorage.getItem("ruser")); }catch{ return null; } });
  const [page, setPage] = useState("dashboard");
  const [open, setOpen] = useState(false);

  const onLogin = (t,u) => { setToken(t); setUser(u); };
  const onLogout = () => { localStorage.removeItem("rtoken"); localStorage.removeItem("ruser"); setToken(null); setUser(null); };

  if(!token) return <LoginPage onLogin={onLogin} />;

  const NAV = [
    {id:"dashboard", label:"الداشبورد",       icon:"dashboard"},
    {id:"orders",    label:"الطلبات",          icon:"orders"},
    {id:"menu",      label:"المنيو",           icon:"menu"},
    {id:"offers",    label:"الأوفر والعروض",   icon:"coupons"},
    {id:"branches",  label:"الفروع والمناطق",  icon:"branches"},
    {id:"customers", label:"العملاء",          icon:"customers"},
    {id:"coupons",   label:"الكوبونات",        icon:"coupons"},
    {id:"reports",   label:"التقارير",         icon:"chart"},
    {id:"settings",  label:"الإعدادات",        icon:"settings"},
  ];

  const PAGES = {
    dashboard: DashboardPage,
    orders:    OrdersPage,
    menu:      MenuPage,
    offers:    OffersPage,
    branches:  BranchesPage,
    customers: CustomersPage,
    coupons:   CouponsPage,
    reports:   ReportsPage,
    settings:  SettingsPage,
  };
  const Page = PAGES[page];

  const Sidebar = () => (
    <aside className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-gradient-to-br from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center text-xl shadow-lg rotate-3">🍽️</div>
          <div>
            <div className="font-black text-gray-900 leading-tight">لوحة التحكم</div>
            <div className="text-xs text-gray-400 mt-0.5">{user?.name}</div>
          </div>
        </div>
      </div>
      {/* Nav */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {NAV.map(item=>(
          <button key={item.id} onClick={()=>{ setPage(item.id); setOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-semibold transition-all text-right
              ${page===item.id
                ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg shadow-amber-200"
                : "text-gray-600 hover:bg-amber-50 hover:text-amber-700"}`}>
            <Icon n={item.icon} size={18} />
            {item.label}
          </button>
        ))}
      </nav>
      {/* Logout */}
      <div className="p-4 border-t border-gray-100">
        <button onClick={onLogout} className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-semibold text-gray-500 hover:bg-red-50 hover:text-red-500 transition-all">
          <Icon n="logout" size={18} /> تسجيل الخروج
        </button>
      </div>
    </aside>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex" dir="rtl">
      {/* Desktop sidebar */}
      <div className="hidden lg:flex flex-col w-64 bg-white border-l border-gray-100 shadow-sm fixed inset-y-0 right-0 z-30">
        <Sidebar />
      </div>

      {/* Mobile sidebar */}
      {open && (
        <>
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden" onClick={()=>setOpen(false)} />
          <div className="fixed inset-y-0 right-0 w-72 bg-white z-50 lg:hidden shadow-2xl flex flex-col">
            <Sidebar />
          </div>
        </>
      )}

      {/* Main Content */}
      <main className="flex-1 lg:mr-64 flex flex-col min-w-0 min-h-screen">
        {/* Header */}
        <header className="bg-white border-b border-gray-100 px-5 py-4 flex items-center gap-4 sticky top-0 z-20 shadow-sm">
          <button onClick={()=>setOpen(true)} className="lg:hidden w-9 h-9 flex items-center justify-center rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-600 transition-colors">
            <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
          </button>
          <h1 className="font-black text-gray-900">{NAV.find(n=>n.id===page)?.label}</h1>
          <div className="mr-auto text-xs text-gray-400 bg-gray-100 px-3 py-1.5 rounded-full">
            {new Date().toLocaleDateString('ar-EG',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 p-5 md:p-6 overflow-y-auto">
          <Page token={token} />
        </div>
      </main>
    </div>
  );
}
