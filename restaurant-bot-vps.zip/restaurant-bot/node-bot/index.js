// bot/index.js - WhatsApp AI Agent with Gemini
const express = require('express');
const axios = require('axios');
const app = express();
app.use(express.json());

// ─── Config ──────────────────────────────────────────────────
const CONFIG = {
  PHP_API: process.env.PHP_API_URL || 'https://yourdomain.infinityfreeapp.com/api',
  GEMINI_KEY: process.env.GEMINI_API_KEY,
  WAHA_URL: process.env.WAHA_URL || 'http://localhost:3000',
  WAHA_KEY: process.env.WAHA_API_KEY || '',
  WAHA_SESSION: process.env.WAHA_SESSION || 'default',
  PORT: process.env.PORT || 4000,
};

// ─── In-memory conversation store (use Redis in production) ──
const conversations = new Map();

// ─── Helper: Call PHP API ─────────────────────────────────────
async function api(method, path, data = null) {
  try {
    const res = await axios({ method, url: `${CONFIG.PHP_API}/${path}`, data, timeout: 10000 });
    return res.data;
  } catch (e) {
    console.error('API Error:', path, e.message);
    return null;
  }
}

// ─── Helper: Send WhatsApp message ───────────────────────────
async function sendMessage(number, text) {
  try {
    await axios.post(`${CONFIG.WAHA_URL}/api/sendText`, {
      session: CONFIG.WAHA_SESSION,
      chatId: `${number}@c.us`,
      text
    }, { headers: { 'X-Api-Key': CONFIG.WAHA_KEY } });
  } catch (e) {
    console.error('Send error:', e.message);
  }
}

async function sendImage(number, imageUrl, caption = '') {
  try {
    await axios.post(`${CONFIG.WAHA_URL}/api/sendImage`, {
      session: CONFIG.WAHA_SESSION,
      chatId: `${number}@c.us`,
      file: { url: imageUrl },
      caption
    }, { headers: { 'X-Api-Key': CONFIG.WAHA_KEY } });
  } catch (e) {
    console.error('Send image error:', e.message);
    // Fallback to text
    if (caption) await sendMessage(number, caption);
  }
}

// ─── Build AI System Prompt ───────────────────────────────────
async function buildSystemPrompt(customer, branchId) {
  const [menuRes, settingsRes, branchesRes, offersRes, faqRes] = await Promise.all([
    api('GET', `menu/bot-menu?branch_id=${branchId}`),
    api('GET', 'settings/get'),
    api('GET', 'branches/list'),
    api('GET', 'menu/public?branch_id=${branchId}'),
    api('GET', 'settings/faq'),
  ]);

  const settings = settingsRes?.data || {};
  const menu = menuRes?.data || [];
  const branches = branchesRes?.data || [];
  const faqs = faqRes?.data || [];

  // Group menu by category
  const menuByCategory = {};
  menu.forEach(item => {
    if (!menuByCategory[item.category]) menuByCategory[item.category] = [];
    if (item.available) menuByCategory[item.category].push(item);
  });

  const menuText = Object.entries(menuByCategory).map(([cat, items]) => {
    const itemsList = items.map(i =>
      `  - ${i.name}: ${i.final_price} ${settings.currency || 'جنيه'} | وقت التحضير: ${i.preparation_time_minutes} دقيقة${i.is_featured ? ' ⭐ الأكثر طلباً' : ''}${i.is_new ? ' 🆕 جديد' : ''}${i.description ? ` | ${i.description}` : ''}`
    ).join('\n');
    return `📂 ${cat}:\n${itemsList}`;
  }).join('\n\n');

  const branchesText = branches.map(b => {
    const zones = b.zones?.filter(z => z.is_active).map(z =>
      `    • ${z.zone_name}: ${z.delivery_price} ${settings.currency || 'جنيه'} | ${z.delivery_time_minutes} دقيقة`
    ).join('\n') || '    لا توجد مناطق توصيل';
    return `🏪 ${b.name} (${b.is_active ? 'مفتوح' : 'مغلق'})\n  العنوان: ${b.address}\n  مناطق التوصيل:\n${zones}`;
  }).join('\n\n');

  const faqText = faqs.map(f => `س: ${f.question}\nج: ${f.answer}`).join('\n\n');

  const customerInfo = customer?.name
    ? `العميل الحالي: ${customer.name} | عدد طلباته: ${customer.total_orders} | ${customer.favorite_items?.length ? 'مفضلاته: ' + customer.favorite_items.map(f => f.item_name).join(', ') : 'عميل جديد'}`
    : 'عميل جديد لم يكمل بياناته بعد';

  return `أنت ${settings.bot_name || 'نور'}، مساعد ذكي لمطعم "${settings.name || 'مطعمنا'}".
${settings.bot_personality || 'بتتكلم بالعربي بأسلوب ودي ومحترم وبتساعد العملاء بكل أسئلتهم.'}

═══════════════════════════════
معلومات العميل:
${customerInfo}
${customer?.last_order ? `آخر طلب: ${customer.last_order.order_number} بتاريخ ${customer.last_order.created_at}` : ''}
═══════════════════════════════

المنيو الكامل:
${menuText}

═══════════════════════════════
الفروع ومناطق التوصيل:
${branchesText}

═══════════════════════════════
أسئلة شائعة:
${faqText}

═══════════════════════════════
تعليمات مهمة:
1. لما العميل يعبر عن رغبته في الطلب، اجمع الأصناف ثم اطلب منه تأكيد الطلب.
2. لما تحتاج إجراء عملي (إنشاء طلب، حفظ عنوان، إلخ)، أضف في نهاية ردك:
   [ACTION:create_order:JSON_DATA] أو [ACTION:save_address:JSON_DATA] أو [ACTION:get_zones:AREA_NAME] أو [ACTION:apply_coupon:CODE]
3. لو المطعم ${settings.is_open ? 'مفتوح' : 'مغلق الآن'}.
4. اقترح أصناف بناءً على تفضيلات العميل وطلباته السابقة.
5. كن ودياً وطبيعياً، مش روبوت.
6. لو حد سألك عن حاجة مش في المنيو، اعتذر بأدب واقترح بديل.
7. الحد الأدنى للطلب: ${settings.min_order_amount || 0} جنيه.
8. دايماً أكد السعر الإجمالي قبل إنشاء الطلب.`;
}

// ─── Call Gemini API ──────────────────────────────────────────
async function callGemini(systemPrompt, messages) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${CONFIG.GEMINI_KEY}`;

  // Format conversation history for Gemini
  const contents = [];

  // Add system prompt as first user message
  contents.push({
    role: 'user',
    parts: [{ text: `[SYSTEM INSTRUCTIONS - ALWAYS FOLLOW THESE]\n${systemPrompt}` }]
  });
  contents.push({
    role: 'model',
    parts: [{ text: 'مفهوم، هساعد العملاء بكل حاجة يحتاجوها! 😊' }]
  });

  // Add conversation history
  messages.forEach(msg => {
    contents.push({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.content }]
    });
  });

  try {
    const res = await axios.post(url, {
      contents,
      generationConfig: {
        temperature: 0.8,
        maxOutputTokens: 1024,
        topP: 0.9,
      },
      safetySettings: [
        { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
      ]
    }, { timeout: 30000 });

    return res.data.candidates?.[0]?.content?.parts?.[0]?.text || 'عذراً، حدث خطأ. حاول مرة تانية.';
  } catch (e) {
    console.error('Gemini error:', e.response?.data || e.message);
    return 'عذراً، في مشكلة مؤقتة. حاول تاني بعد شوية! 🙏';
  }
}

// ─── Parse AI Actions ─────────────────────────────────────────
function parseActions(text) {
  const actions = [];
  const actionRegex = /\[ACTION:(\w+):([^\]]+)\]/g;
  let match;
  while ((match = actionRegex.exec(text)) !== null) {
    actions.push({ type: match[1], data: match[2] });
  }
  const cleanText = text.replace(actionRegex, '').trim();
  return { text: cleanText, actions };
}

// ─── Execute AI Actions ───────────────────────────────────────
async function executeActions(actions, conv, number) {
  for (const action of actions) {
    try {
      if (action.type === 'create_order') {
        const orderData = JSON.parse(action.data);
        orderData.whatsapp_number = number;
        const res = await api('POST', 'orders/create', orderData);
        if (res?.success) {
          const msg = `✅ تم تسجيل طلبك بنجاح!\n\n🔢 رقم الطلب: ${res.data.order_number}\n💰 الإجمالي: ${res.data.total} ${res.data.currency}\n⏱️ وقت التوصيل المتوقع: ${res.data.estimated_time} دقيقة\n\nسنرسل لك تحديثات على واتساب 🙏`;
          await sendMessage(number, msg);
          conv.cart = [];
          conv.state = 'idle';
        }
      }

      if (action.type === 'save_address') {
        const addrData = JSON.parse(action.data);
        addrData.customer_id = conv.customer?.id;
        await api('POST', 'customers/add-address', addrData);
      }

      if (action.type === 'get_zones') {
        const zonesRes = await api('GET', `branches/find-zone?area=${encodeURIComponent(action.data)}`);
        if (zonesRes?.data?.length) {
          conv.availableZones = zonesRes.data;
        }
      }

      if (action.type === 'apply_coupon') {
        const couponRes = await api('POST', 'coupons/validate', {
          code: action.data,
          customer_id: conv.customer?.id,
          subtotal: conv.cartTotal || 0
        });
        if (couponRes?.success) {
          conv.appliedCoupon = { code: action.data, discount: couponRes.data.discount };
        }
      }
    } catch (e) {
      console.error('Action error:', action.type, e.message);
    }
  }
}

// ─── Main Message Handler ─────────────────────────────────────
async function handleMessage(number, messageText) {
  console.log(`📱 [${number}]: ${messageText}`);

  // Get or create conversation
  if (!conversations.has(number)) {
    conversations.set(number, {
      history: [],
      customer: null,
      cart: [],
      cartTotal: 0,
      state: 'new',
      branchId: 1,
      appliedCoupon: null,
      availableZones: null,
      lastActivity: Date.now()
    });
  }

  const conv = conversations.get(number);
  conv.lastActivity = Date.now();

  // Load/refresh customer data
  const customerRes = await api('POST', 'customers/get-or-create', { whatsapp_number: number });
  if (customerRes?.data) {
    conv.customer = customerRes.data;
    // Determine branch from customer's area if known
    if (conv.customer.addresses?.length > 0 && conv.customer.addresses[0].zone_id) {
      conv.branchId = conv.customer.addresses[0].zone_id;
    }
  }

  // Check if blacklisted
  if (conv.customer?.is_blacklisted) {
    await sendMessage(number, 'عذراً، لا يمكن معالجة طلبك حالياً. للاستفسار تواصل معنا مباشرة.');
    return;
  }

  // Check restaurant status
  const settings = await api('GET', 'settings/get');
  if (settings?.data) {
    if (!settings.data.is_open) {
      await sendMessage(number, settings.data.closed_message || '🔴 المطعم مغلق حالياً. شكراً لتواصلك!');
      return;
    }
    if (settings.data.orders_paused) {
      await sendMessage(number, settings.data.paused_message || '⚠️ الطلبات متوقفة مؤقتاً. حاول مرة تانية بعد قليل!');
      return;
    }
  }

  // Handle rating response (1-5)
  if (/^[1-5]$/.test(messageText.trim()) && conv.state === 'awaiting_rating') {
    const lastOrder = conv.customer?.last_order;
    if (lastOrder) {
      await api('POST', 'orders/rate', {
        order_id: lastOrder.id,
        customer_id: conv.customer.id,
        rating: parseInt(messageText)
      });
      const ratingMsg = parseInt(messageText) >= 4
        ? '🌟 شكراً جزيلاً على تقييمك الرائع! يسعدنا دايماً خدمتك 😊'
        : '🙏 شكراً على تقييمك! هنحاول نتحسن أكتر في المرات الجاية.';
      await sendMessage(number, ratingMsg);
      conv.state = 'idle';
      return;
    }
  }

  // Add message to history
  conv.history.push({ role: 'user', content: messageText });

  // Keep last 20 messages only (context window management)
  if (conv.history.length > 20) {
    conv.history = conv.history.slice(-20);
  }

  // Build fresh system prompt with current data
  const systemPrompt = await buildSystemPrompt(conv.customer, conv.branchId);

  // Call Gemini
  const aiResponse = await callGemini(systemPrompt, conv.history);

  // Parse actions from response
  const { text: cleanResponse, actions } = parseActions(aiResponse);

  // Add AI response to history
  conv.history.push({ role: 'assistant', content: cleanResponse });

  // Send response to user
  if (cleanResponse) {
    await sendMessage(number, cleanResponse);
  }

  // Execute any actions
  if (actions.length > 0) {
    await executeActions(actions, conv, number);
  }
}

// ─── Clean old conversations (every hour) ────────────────────
setInterval(() => {
  const oneHour = 60 * 60 * 1000;
  const now = Date.now();
  for (const [num, conv] of conversations.entries()) {
    if (now - conv.lastActivity > oneHour) {
      conversations.delete(num);
    }
  }
}, 60 * 60 * 1000);

// ─── Webhook endpoint (WAHA sends messages here) ─────────────
app.post('/webhook', async (req, res) => {
  res.sendStatus(200); // Respond quickly to WAHA

  const event = req.body;
  if (event.event !== 'message' || event.payload?.fromMe) return;

  const number = event.payload?.from?.replace('@c.us', '');
  const text = event.payload?.body;
  const type = event.payload?.type;

  if (!number || !text || type !== 'chat') return;

  // Handle in background
  handleMessage(number, text).catch(console.error);
});

// ─── Health check ─────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', conversations: conversations.size, timestamp: new Date() });
});

// ─── Start server ─────────────────────────────────────────────
app.listen(CONFIG.PORT, () => {
  console.log(`🤖 Restaurant AI Bot running on port ${CONFIG.PORT}`);
  console.log(`📱 Webhook: http://localhost:${CONFIG.PORT}/webhook`);
});

// ─── Keep-alive (prevent Render free tier sleep) ──────────────
const SELF_URL = process.env.RENDER_EXTERNAL_URL || `http://localhost:${CONFIG.PORT}`;
setInterval(async () => {
  try {
    await axios.get(`${SELF_URL}/health`, { timeout: 5000 });
    console.log('💓 Keep-alive ping OK');
  } catch(e) {
    console.log('💔 Keep-alive failed:', e.message);
  }
}, 14 * 60 * 1000); // Every 14 minutes

// ─── Admin endpoint: get conversation count ───────────────────
app.get('/stats', (req, res) => {
  const key = req.headers['x-api-key'];
  if (key !== CONFIG.WAHA_KEY) return res.status(401).json({ error: 'unauthorized' });
  res.json({
    conversations: conversations.size,
    active: [...conversations.values()].filter(c => Date.now() - c.lastActivity < 30 * 60 * 1000).length,
    timestamp: new Date()
  });
});

// ─── Clear specific conversation (admin reset) ────────────────
app.delete('/conversation/:number', (req, res) => {
  const key = req.headers['x-api-key'];
  if (key !== CONFIG.WAHA_KEY) return res.status(401).json({ error: 'unauthorized' });
  conversations.delete(req.params.number);
  res.json({ deleted: true });
});
