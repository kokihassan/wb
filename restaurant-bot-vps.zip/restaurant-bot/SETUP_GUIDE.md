# 🍽️ دليل تفعيل نظام المطعم الذكي — خطوة بخطوة

---

## 📦 ملخص المكونات

| المكون | المكان | الغرض |
|--------|--------|-------|
| PHP Backend + Dashboard | Infinityfree | API + لوحة التحكم |
| MySQL Database | Infinityfree | تخزين البيانات |
| WAHA | Render.com | تشغيل واتساب |
| Node.js Bot | Render.com | AI Agent + Gemini |

---

## 🗄️ الخطوة 1 — إنشاء قاعدة البيانات

1. ادخل على **Infinityfree Control Panel**
2. اذهب لـ **MySQL Databases**
3. اعمل قاعدة بيانات جديدة — احتفظ بـ:
   - اسم القاعدة
   - اسم المستخدم
   - كلمة المرور
4. افتح **phpMyAdmin**
5. اختر القاعدة الجديدة
6. اذهب لـ **Import** ← اختر ملف `schema.sql`
7. اضغط **Go** ← انتظر حتى يكتمل

✅ المفروض تشوف 22+ جدول اتعملوا

---

## ⚙️ الخطوة 2 — رفع PHP Backend

### تعديل `config.php` أولاً:
```php
define('DB_HOST', 'sql206.infinityfree.com'); // من Infinityfree
define('DB_NAME', 'if0_XXXXXXXX_restaurant'); // اسم قاعدتك
define('DB_USER', 'if0_XXXXXXXX');            // اسم المستخدم
define('DB_PASS', 'your_password');           // كلمة المرور

define('GEMINI_API_KEY', 'AIzaSy...');        // من الخطوة 3
define('WAHA_URL', 'https://waha-xxx.onrender.com'); // من الخطوة 4
define('WAHA_API_KEY', 'your-secret-key');
define('NODE_BOT_URL', 'https://bot-xxx.onrender.com'); // من الخطوة 5

define('APP_URL', 'https://yourdomain.infinityfreeapp.com');
define('JWT_SECRET', 'اكتب_هنا_60_حرف_عشوائي_على_الأقل');
```

### رفع الملفات:
1. افتح **File Manager** في Infinityfree
2. اذهب لمجلد `htdocs`
3. ارفع محتويات مجلد `php-backend/` بالكامل
4. تأكد إن البنية هكذا:
```
htdocs/
├── .htaccess
├── config.php
├── index.php
├── api/
│   ├── auth.php
│   ├── menu.php
│   ├── orders.php
│   ├── branches.php
│   ├── customers.php
│   ├── coupons.php
│   ├── settings.php
│   └── webhook.php
└── uploads/  ← اعمله يدوياً وحط permissions 755
```

### اختبار الـ API:
افتح في المتصفح:
```
https://yourdomain.infinityfreeapp.com/api/settings/get
```
المفروض ترجع:
```json
{"success": true, "data": {...}}
```

---

## 🔑 الخطوة 3 — Gemini API Key (مجاني)

1. اذهب لـ **https://aistudio.google.com/app/apikey**
2. سجّل دخول بحساب Google
3. اضغط **Create API Key**
4. انسخ الـ Key وحطه في `config.php` و `.env`

📌 الـ Free tier يكفي لـ 15 request/دقيقة — كافي للبداية

---

## 🐳 الخطوة 4 — تشغيل WAHA على Render

### إنشاء Web Service على Render.com:

1. اذهب لـ **https://render.com** واعمل حساب
2. اضغط **New → Web Service**
3. اختر **Deploy from existing image**
4. Image: `devlikeapro/waha`
5. الإعدادات:
   - Name: `waha-restaurant`
   - Plan: **Free**
   - Environment Variables:
     ```
     WHATSAPP_API_KEY = اكتب_مفتاح_سري_هنا (مثلاً: myrestaurant2024)
     ```
6. اضغط **Create Web Service**
7. انتظر حتى يشتغل (3-5 دقائق)
8. احتفظ بالـ URL مثل: `https://waha-restaurant.onrender.com`

### ربط واتساب:
1. افتح: `https://your-waha.onrender.com/dashboard`
2. اضغط **Start Session**
3. امسح الـ QR code بواتساب المطعم:
   - واتساب → ⋮ → Linked Devices → Link a Device
4. انتظر حتى يتحول لـ **CONNECTED** ✅

---

## 🤖 الخطوة 5 — Deploy Node Bot على Render

1. ارفع محتويات مجلد `node-bot/` على GitHub (repo جديد)
2. في Render → **New → Web Service**
3. اربطه بالـ repo
4. الإعدادات:
   - Name: `restaurant-bot`
   - Runtime: **Node**
   - Build Command: `npm install`
   - Start Command: `node index.js`
   - Plan: **Free**
5. Environment Variables:
   ```
   PHP_API_URL     = https://yourdomain.infinityfreeapp.com/api
   GEMINI_API_KEY  = AIzaSy... (من الخطوة 3)
   WAHA_URL        = https://waha-restaurant.onrender.com
   WAHA_API_KEY    = myrestaurant2024 (نفس اللي في WAHA)
   WAHA_SESSION    = default
   PORT            = 4000
   ```
6. اضغط **Deploy** وانتظر

### ربط Webhook:
1. في WAHA Dashboard → **Sessions** → **default** → **Edit**
2. Webhook URL:
   ```
   https://restaurant-bot.onrender.com/webhook
   ```
3. Events: فعّل **message**
4. احفظ

### اختبار:
افتح: `https://restaurant-bot.onrender.com/health`
المفروض ترجع: `{"status":"ok","conversations":0,...}`

---

## 🎨 الخطوة 6 — Dashboard (لوحة التحكم)

الـ Dashboard جاهز كـ React Component في ملف `RestaurantDashboard.jsx`

### طريقة استخدامه على Infinityfree:

#### الأسهل — HTML Page:
1. اعمل ملف `admin.html` في htdocs
2. استخدم CDN لـ React:

```html
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>لوحة تحكم المطعم</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- حماية بسيطة - غير هذا الباسورد -->
  <script>
    if(sessionStorage.getItem('da') !== '1') {
      const p = prompt('كلمة المرور:');
      if(p !== 'admin123') { document.write('غير مصرح'); throw ''; }
      sessionStorage.setItem('da','1');
    }
  </script>
</head>
<body>
  <div id="root"></div>
  <script src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <!-- الـ Dashboard Component كـ script type text/babel -->
  <script type="text/babel" src="dashboard-bundle.js"></script>
</body>
</html>
```

#### الأفضل — على Netlify مجاناً:
1. اعمل مجلد `dashboard/` وفيه:
   - `RestaurantDashboard.jsx`
   - `index.html` و `package.json`
2. اعمل `npm run build`
3. ارفع مجلد `dist/` على Netlify Drop
4. URL جديد للداشبورد مثل: `https://restaurant-admin.netlify.app`

---

## 🚀 الخطوة 7 — إعداد أول بيانات

### تسجيل الدخول للداشبورد:
- Email: `admin@restaurant.com`
- Password: `password`
- ⚠️ **غيّر كلمة المرور فوراً** من الإعدادات

### إضافة الفروع:
1. اذهب لـ **الفروع والمناطق**
2. أضف فرع أ وفرع ب
3. لكل فرع أضف مناطق التوصيل مع الأسعار

### رفع المنيو:
**الطريقة الأسرع — Excel:**
1. اضغط **تحميل Template Excel**
2. افتح الـ CSV وأملاه:
   ```
   القسم,اسم الصنف,الوصف,السعر,وقت التحضير,متاح
   مشويات,كباب مشوي,كباب طازج على الفحم,45,20,نعم
   مشويات,كفتة مشوية,كفتة لحم بالتوابل,40,15,نعم
   بيتزا,مارجريتا,جبنة موزاريلا وصلصة طماطم,60,25,نعم
   ```
3. احفظ كـ CSV
4. ارفعه بزر **استيراد Excel**
5. بعد الاستيراد أضف صور الأصناف من الداشبورد

### إعداد البوت:
1. اذهب لـ **الإعدادات → البوت**
2. اكتب اسم البوت (مثلاً: نور)
3. اكتب شخصية البوت وتعليماته
4. أضف أسئلة شائعة

---

## ✅ الخطوة 8 — اختبار النظام كامل

### اختبار البوت:
1. بعث رسالة على رقم واتساب المطعم: **"مرحبا"**
2. المفروض يرد البوت تلقائياً
3. جرّب: "عايز أشوف المنيو"
4. جرّب: "عايز أطلب كباب"
5. جرّب: "بتوصلوا المعادي؟"

### اختبار الداشبورد:
1. سجّل دخول على الداشبورد
2. شيك الداشبورد الرئيسي
3. شيك صفحة الطلبات
4. جرّب تغيير ستاتوس طلب
5. تأكد إن العميل اتبعتله رسالة واتساب

---

## 🔧 مشاكل شائعة وحلولها

| المشكلة | الحل |
|---------|------|
| API بيرجع 500 | تحقق من بيانات DB في config.php |
| البوت مش بيرد | تحقق من WAHA Session - لازم CONNECTED |
| صور مش بترفع | تأكد مجلد uploads/ موجود وحقوقه 755 |
| Render بيتوقف | Free tier بيتوقف بعد 15 دقيقة عدم نشاط — طبيعي |
| Gemini بطيء | Free tier = 15 req/min — كافي |

---

## 🔄 إبقاء Render شغّال (مهم!)

Free tier على Render بيتوقف بعد 15 دقيقة idle.
أضف هذا الكود في `index.js`:
```js
// Keep alive ping every 14 minutes
setInterval(() => {
  fetch('https://restaurant-bot.onrender.com/health')
    .catch(() => {});
}, 14 * 60 * 1000);
```

أو استخدم **UptimeRobot** (مجاني):
1. https://uptimerobot.com
2. New Monitor → HTTP(s)
3. URL: `https://restaurant-bot.onrender.com/health`
4. Interval: 5 minutes

---

## 📱 الكود الكامل — ملخص الملفات

```
📁 php-backend/         → ارفعه على Infinityfree/htdocs
   ├── config.php       → ⚠️ عدّل القيم أولاً
   ├── .htaccess
   ├── index.php
   └── api/
       ├── auth.php
       ├── menu.php
       ├── orders.php
       ├── branches.php
       ├── customers.php
       ├── coupons.php
       ├── settings.php
       └── webhook.php

📁 node-bot/            → ارفعه على GitHub ثم Render
   ├── index.js
   ├── package.json
   ├── .env.example     → انسخه لـ .env وعدّله
   └── render.yaml

📁 database/
   └── schema.sql       → استوردها على phpMyAdmin

📄 RestaurantDashboard.jsx → افتحه في Claude كـ Artifact
```

---

## 💡 نصائح إضافية

- **النسخ الاحتياطي**: اعمل export للـ DB كل أسبوع من phpMyAdmin
- **الأمان**: غيّر JWT_SECRET وكلمة مرور الأدمن فوراً
- **مراقبة**: تابع logs البوت من `https://your-bot.onrender.com/health`
- **تطوير**: ابدأ بـ Sandbox Mode في WAHA للتجربة

---

**المطور:** نظام جاهز للإنتاج — وفّقك الله! 🚀
