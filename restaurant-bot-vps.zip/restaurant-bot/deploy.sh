#!/bin/bash
# ============================================================
# deploy.sh — رفع ملفات المشروع على VPS
# شغّله من جهازك: bash deploy.sh
# ============================================================

# ─── إعدادات — عدّل هذه القيم ────────────────────────────
VPS_IP="YOUR_VPS_IP"           # IP السيرفر
VPS_USER="root"                # اسم المستخدم (root أو ubuntu)
VPS_PATH="/var/www/restaurant"
# ─────────────────────────────────────────────────────────

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
log()  { echo -e "${GREEN}[✓]${NC} $1"; }
info() { echo -e "${YELLOW}[→]${NC} $1"; }

echo -e "${GREEN}🚀 رفع ملفات المشروع على VPS...${NC}"
echo ""

# ─── 1. PHP API files ────────────────────────────────────
info "رفع PHP API..."
scp php-backend/api/*.php ${VPS_USER}@${VPS_IP}:${VPS_PATH}/api/
log "تم رفع PHP API"

# ─── 2. Node Bot ─────────────────────────────────────────
info "رفع Node Bot..."
scp node-bot/index.js ${VPS_USER}@${VPS_IP}:${VPS_PATH}/bot/
log "تم رفع Node Bot"

# ─── 3. Restart bot ──────────────────────────────────────
info "إعادة تشغيل البوت..."
ssh ${VPS_USER}@${VPS_IP} "pm2 restart restaurant-bot && pm2 save"
log "تم إعادة تشغيل البوت"

echo ""
echo -e "${GREEN}✅ تم رفع كل الملفات!${NC}"
echo -e "🌐 API: http://${VPS_IP}/api/health"
