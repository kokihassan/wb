#!/bin/bash
# ============================================================
# 🍽️ Restaurant Bot - VPS Auto Install Script
# Ubuntu 20.04 / 22.04
# شغّله كـ root: bash install.sh
# ============================================================

set -e  # Stop on any error

# ─── Colors ──────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
info() { echo -e "${BLUE}[→]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════╗"
echo "║   🍽️  Restaurant AI Bot - VPS Installer  ║"
echo "║   Ubuntu 20.04 / 22.04                   ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"

# ─── Check root ───────────────────────────────────────────────
[ "$EUID" -ne 0 ] && err "شغّل السكريبت كـ root: sudo bash install.sh"

# ─── Get server IP ────────────────────────────────────────────
SERVER_IP=$(curl -s ifconfig.me || curl -s ipinfo.io/ip)
log "Server IP: $SERVER_IP"

# ─── Collect config from user ────────────────────────────────
echo ""
echo -e "${CYAN}══════════ إعداد المشروع ══════════${NC}"

read -p "$(echo -e ${YELLOW}"اسم المطعم: "${NC})" RESTAURANT_NAME
RESTAURANT_NAME=${RESTAURANT_NAME:-"مطعمي"}

read -p "$(echo -e ${YELLOW}"Gemini API Key (من aistudio.google.com): "${NC})" GEMINI_KEY
[ -z "$GEMINI_KEY" ] && err "Gemini API Key مطلوب"

read -p "$(echo -e ${YELLOW}"كلمة مرور MySQL (اختارها أنت): "${NC})" MYSQL_PASS
MYSQL_PASS=${MYSQL_PASS:-"RestBot$(date +%s)!"}

read -p "$(echo -e ${YELLOW}"WAHA API Key (اختارها أنت مثلاً: mybot2024): "${NC})" WAHA_KEY
WAHA_KEY=${WAHA_KEY:-"wahakey$(date +%s)"}

read -p "$(echo -e ${YELLOW}"كلمة مرور لوحة التحكم (Admin): "${NC})" ADMIN_PASS
ADMIN_PASS=${ADMIN_PASS:-"admin123"}

JWT_SECRET=$(openssl rand -hex 32)

echo ""
log "الإعدادات جاهزة، نبدأ التثبيت..."
echo ""

# ════════════════════════════════════════════════════════════
# STEP 1: System Update
# ════════════════════════════════════════════════════════════
info "تحديث النظام..."
apt-get update -qq
apt-get upgrade -y -qq
apt-get install -y -qq curl wget git unzip software-properties-common \
    apt-transport-https ca-certificates gnupg lsb-release ufw
log "تم تحديث النظام"

# ════════════════════════════════════════════════════════════
# STEP 2: Nginx
# ════════════════════════════════════════════════════════════
info "تثبيت Nginx..."
apt-get install -y -qq nginx
systemctl enable nginx
systemctl start nginx
log "تم تثبيت Nginx"

# ════════════════════════════════════════════════════════════
# STEP 3: PHP 8.1
# ════════════════════════════════════════════════════════════
info "تثبيت PHP 8.1..."
add-apt-repository -y ppa:ondrej/php > /dev/null 2>&1
apt-get update -qq
apt-get install -y -qq \
    php8.1-fpm php8.1-mysql php8.1-curl php8.1-mbstring \
    php8.1-xml php8.1-zip php8.1-gd php8.1-intl php8.1-bcmath
systemctl enable php8.1-fpm
systemctl start php8.1-fpm
log "تم تثبيت PHP 8.1"

# ════════════════════════════════════════════════════════════
# STEP 4: MySQL
# ════════════════════════════════════════════════════════════
info "تثبيت MySQL..."
apt-get install -y -qq mysql-server

# Secure MySQL
mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '${MYSQL_PASS}';" 2>/dev/null || true
mysql -u root -p"${MYSQL_PASS}" -e "DELETE FROM mysql.user WHERE User='';" 2>/dev/null || true
mysql -u root -p"${MYSQL_PASS}" -e "DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost','127.0.0.1','::1');" 2>/dev/null || true
mysql -u root -p"${MYSQL_PASS}" -e "DROP DATABASE IF EXISTS test;" 2>/dev/null || true
mysql -u root -p"${MYSQL_PASS}" -e "FLUSH PRIVILEGES;" 2>/dev/null || true

# Create database and user
mysql -u root -p"${MYSQL_PASS}" << MYSQL_EOF
CREATE DATABASE IF NOT EXISTS restaurant_bot CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'botuser'@'localhost' IDENTIFIED BY '${MYSQL_PASS}';
GRANT ALL PRIVILEGES ON restaurant_bot.* TO 'botuser'@'localhost';
FLUSH PRIVILEGES;
MYSQL_EOF

log "تم تثبيت MySQL وإنشاء قاعدة البيانات"

# ════════════════════════════════════════════════════════════
# STEP 5: Node.js 18
# ════════════════════════════════════════════════════════════
info "تثبيت Node.js 18..."
curl -fsSL https://deb.nodesource.com/setup_18.x | bash - > /dev/null 2>&1
apt-get install -y -qq nodejs
log "تم تثبيت Node.js $(node --version)"

# ════════════════════════════════════════════════════════════
# STEP 6: PM2
# ════════════════════════════════════════════════════════════
info "تثبيت PM2..."
npm install -g pm2 -q
pm2 startup systemd -u root --hp /root > /dev/null 2>&1
log "تم تثبيت PM2"

# ════════════════════════════════════════════════════════════
# STEP 7: Docker (for WAHA)
# ════════════════════════════════════════════════════════════
info "تثبيت Docker..."
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg 2>/dev/null
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" > /etc/apt/sources.list.d/docker.list
apt-get update -qq
apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin
systemctl enable docker
systemctl start docker
log "تم تثبيت Docker"

# ════════════════════════════════════════════════════════════
# STEP 8: Create project structure
# ════════════════════════════════════════════════════════════
info "إنشاء هيكل المشروع..."
mkdir -p /var/www/restaurant/{api,uploads/{items,categories,offers,settings},logs}
mkdir -p /var/www/restaurant/bot
mkdir -p /var/www/restaurant/dashboard

# Set permissions
chown -R www-data:www-data /var/www/restaurant
chmod -R 755 /var/www/restaurant
chmod -R 775 /var/www/restaurant/uploads
chmod -R 775 /var/www/restaurant/logs
log "تم إنشاء الهيكل"

# ════════════════════════════════════════════════════════════
# STEP 9: Deploy PHP Backend
# ════════════════════════════════════════════════════════════
info "نشر PHP Backend..."

# config.php
cat > /var/www/restaurant/config.php << PHPEOF
<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'restaurant_bot');
define('DB_USER', 'botuser');
define('DB_PASS', '${MYSQL_PASS}');
define('DB_CHARSET', 'utf8mb4');

define('GEMINI_API_KEY', '${GEMINI_KEY}');
define('WAHA_URL', 'http://localhost:3000');
define('WAHA_API_KEY', '${WAHA_KEY}');
define('WAHA_SESSION', 'default');
define('NODE_BOT_URL', 'http://localhost:4000');

define('APP_URL', 'http://${SERVER_IP}');
define('UPLOAD_PATH', '/var/www/restaurant/uploads/');
define('UPLOAD_URL', 'http://${SERVER_IP}/uploads/');
define('JWT_SECRET', '${JWT_SECRET}');
define('ADMIN_SESSION_LIFETIME', 86400);

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
if (\$_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit(); }

function getDB() {
    static \$pdo = null;
    if (\$pdo === null) {
        try {
            \$dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET;
            \$pdo = new PDO(\$dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException \$e) {
            http_response_code(500);
            die(json_encode(['error' => 'DB connection failed: ' . \$e->getMessage()]));
        }
    }
    return \$pdo;
}

function success(\$data = [], \$message = 'success', \$code = 200) {
    http_response_code(\$code);
    echo json_encode(['success' => true, 'message' => \$message, 'data' => \$data], JSON_UNESCAPED_UNICODE);
    exit();
}

function error(\$message = 'Error', \$code = 400, \$data = []) {
    http_response_code(\$code);
    echo json_encode(['success' => false, 'message' => \$message, 'data' => \$data], JSON_UNESCAPED_UNICODE);
    exit();
}

function generateToken(\$payload) {
    \$h = rtrim(base64_encode(json_encode(['alg'=>'HS256','typ'=>'JWT'])), '=');
    \$payload['iat'] = time(); \$payload['exp'] = time() + ADMIN_SESSION_LIFETIME;
    \$p = rtrim(base64_encode(json_encode(\$payload)), '=');
    \$s = rtrim(base64_encode(hash_hmac('sha256', "\$h.\$p", JWT_SECRET, true)), '=');
    return "\$h.\$p.\$s";
}

function verifyToken(\$token) {
    \$parts = explode('.', \$token);
    if (count(\$parts) !== 3) return false;
    [\$h, \$p, \$s] = \$parts;
    \$expected = rtrim(base64_encode(hash_hmac('sha256', "\$h.\$p", JWT_SECRET, true)), '=');
    if (!hash_equals(\$s, \$expected)) return false;
    \$data = json_decode(base64_decode(\$p . str_repeat('=', 4 - strlen(\$p) % 4)), true);
    if (!\$data || \$data['exp'] < time()) return false;
    return \$data;
}

function requireAuth() {
    \$headers = getallheaders();
    \$auth = \$headers['Authorization'] ?? \$headers['authorization'] ?? '';
    if (!str_starts_with(\$auth, 'Bearer ')) error('Unauthorized', 401);
    \$data = verifyToken(substr(\$auth, 7));
    if (!\$data) error('Invalid or expired token', 401);
    return \$data;
}

function uploadImage(\$file, \$folder = 'items') {
    \$uploadDir = UPLOAD_PATH . \$folder . '/';
    if (!is_dir(\$uploadDir)) mkdir(\$uploadDir, 0775, true);
    \$allowed = ['jpg','jpeg','png','webp','gif'];
    \$ext = strtolower(pathinfo(\$file['name'], PATHINFO_EXTENSION));
    if (!in_array(\$ext, \$allowed) || \$file['size'] > 5*1024*1024) return false;
    \$filename = uniqid() . '_' . time() . '.' . \$ext;
    if (move_uploaded_file(\$file['tmp_name'], \$uploadDir . \$filename)) {
        return UPLOAD_URL . \$folder . '/' . \$filename;
    }
    return false;
}

function generateOrderNumber() {
    \$db = getDB();
    \$stmt = \$db->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()");
    \$count = \$stmt->fetchColumn() + 1;
    return 'ORD-' . date('Ymd') . '-' . str_pad(\$count, 4, '0', STR_PAD_LEFT);
}

function sendWhatsApp(\$number, \$message, \$imageUrl = null) {
    \$url = WAHA_URL . '/api/sendText';
    \$data = ['session' => WAHA_SESSION, 'chatId' => \$number . '@c.us', 'text' => \$message];
    if (\$imageUrl) {
        \$url = WAHA_URL . '/api/sendImage';
        \$data = ['session' => WAHA_SESSION, 'chatId' => \$number . '@c.us', 'file' => ['url' => \$imageUrl], 'caption' => \$message];
    }
    \$ch = curl_init(\$url);
    curl_setopt_array(\$ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode(\$data),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'X-Api-Key: ' . WAHA_API_KEY],
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10]);
    \$result = curl_exec(\$ch); curl_close(\$ch);
    return json_decode(\$result, true);
}
PHPEOF

log "تم إنشاء config.php"

# ════════════════════════════════════════════════════════════
# STEP 10: Import Database Schema
# ════════════════════════════════════════════════════════════
info "استيراد قاعدة البيانات..."

# Create schema inline
mysql -u botuser -p"${MYSQL_PASS}" restaurant_bot << 'SQLEOF'
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS restaurant_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL DEFAULT 'مطعمي',
  logo VARCHAR(255),phone VARCHAR(20),email VARCHAR(100),
  welcome_message TEXT,bot_name VARCHAR(50) DEFAULT 'نور',
  bot_personality TEXT,min_order_amount DECIMAL(10,2) DEFAULT 0,
  tax_percentage DECIMAL(5,2) DEFAULT 0,currency VARCHAR(10) DEFAULT 'جنيه',
  is_open TINYINT(1) DEFAULT 1,closed_message TEXT,
  orders_paused TINYINT(1) DEFAULT 0,paused_message TEXT,
  facebook VARCHAR(255),instagram VARCHAR(255),website VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS branches (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,address TEXT NOT NULL,
  phone VARCHAR(20),whatsapp_number VARCHAR(20),notification_phone VARCHAR(20),
  latitude DECIMAL(10,8),longitude DECIMAL(11,8),
  is_active TINYINT(1) DEFAULT 1,sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS working_hours (
  id INT AUTO_INCREMENT PRIMARY KEY,branch_id INT,
  day_of_week TINYINT NOT NULL,open_time TIME,close_time TIME,
  is_closed TINYINT(1) DEFAULT 0,
  FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS delivery_zones (
  id INT AUTO_INCREMENT PRIMARY KEY,branch_id INT NOT NULL,
  zone_name VARCHAR(100) NOT NULL,delivery_price DECIMAL(10,2) NOT NULL DEFAULT 0,
  delivery_time_minutes INT NOT NULL DEFAULT 45,min_order_amount DECIMAL(10,2) DEFAULT 0,
  notes TEXT,is_active TINYINT(1) DEFAULT 1,sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,
  name_en VARCHAR(100),description TEXT,image VARCHAR(255),
  icon VARCHAR(50),sort_order INT DEFAULT 0,is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS menu_items (
  id INT AUTO_INCREMENT PRIMARY KEY,category_id INT NOT NULL,
  name VARCHAR(150) NOT NULL,name_en VARCHAR(150),description TEXT,
  price DECIMAL(10,2) NOT NULL,image VARCHAR(255),
  preparation_time_minutes INT DEFAULT 15,calories INT,
  is_available TINYINT(1) DEFAULT 1,is_featured TINYINT(1) DEFAULT 0,
  is_new TINYINT(1) DEFAULT 0,is_spicy TINYINT(1) DEFAULT 0,
  is_vegetarian TINYINT(1) DEFAULT 0,tags VARCHAR(255),
  sort_order INT DEFAULT 0,total_orders INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS item_branch_availability (
  id INT AUTO_INCREMENT PRIMARY KEY,item_id INT NOT NULL,branch_id INT NOT NULL,
  is_available TINYINT(1) DEFAULT 1,override_price DECIMAL(10,2) NULL,notes VARCHAR(255),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (item_id) REFERENCES menu_items(id) ON DELETE CASCADE,
  FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE,
  UNIQUE KEY unique_item_branch (item_id, branch_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS item_sizes (
  id INT AUTO_INCREMENT PRIMARY KEY,item_id INT NOT NULL,
  size_name VARCHAR(50) NOT NULL,price_addition DECIMAL(10,2) DEFAULT 0,
  is_default TINYINT(1) DEFAULT 0,sort_order INT DEFAULT 0,
  FOREIGN KEY (item_id) REFERENCES menu_items(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS item_extras (
  id INT AUTO_INCREMENT PRIMARY KEY,item_id INT NOT NULL,
  name VARCHAR(100) NOT NULL,price DECIMAL(10,2) DEFAULT 0,
  is_available TINYINT(1) DEFAULT 1,sort_order INT DEFAULT 0,
  FOREIGN KEY (item_id) REFERENCES menu_items(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
  id INT AUTO_INCREMENT PRIMARY KEY,whatsapp_number VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(100),phone VARCHAR(20),email VARCHAR(100),notes TEXT,
  is_blacklisted TINYINT(1) DEFAULT 0,blacklist_reason TEXT,
  total_orders INT DEFAULT 0,total_spent DECIMAL(10,2) DEFAULT 0,
  last_order_at TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_whatsapp (whatsapp_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customer_addresses (
  id INT AUTO_INCREMENT PRIMARY KEY,customer_id INT NOT NULL,
  label VARCHAR(50) DEFAULT 'بيت',address TEXT NOT NULL,
  area VARCHAR(100),zone_id INT NULL,is_default TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
  FOREIGN KEY (zone_id) REFERENCES delivery_zones(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS coupons (
  id INT AUTO_INCREMENT PRIMARY KEY,code VARCHAR(50) NOT NULL UNIQUE,
  description VARCHAR(255),type ENUM('percentage','fixed') NOT NULL DEFAULT 'percentage',
  value DECIMAL(10,2) NOT NULL,min_order_amount DECIMAL(10,2) DEFAULT 0,
  max_discount DECIMAL(10,2) NULL,usage_limit INT NULL,usage_per_customer INT DEFAULT 1,
  used_count INT DEFAULT 0,valid_from TIMESTAMP NULL,valid_until TIMESTAMP NULL,
  applicable_to ENUM('all','category','item') DEFAULT 'all',applicable_ids TEXT,
  is_active TINYINT(1) DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS offers (
  id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150) NOT NULL,
  description TEXT,image VARCHAR(255),
  type ENUM('combo','free_item','discount') DEFAULT 'combo',
  price DECIMAL(10,2),valid_from TIMESTAMP NULL,valid_until TIMESTAMP NULL,
  is_active TINYINT(1) DEFAULT 1,sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS offer_items (
  id INT AUTO_INCREMENT PRIMARY KEY,offer_id INT NOT NULL,item_id INT NOT NULL,quantity INT DEFAULT 1,
  FOREIGN KEY (offer_id) REFERENCES offers(id) ON DELETE CASCADE,
  FOREIGN KEY (item_id) REFERENCES menu_items(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,order_number VARCHAR(20) NOT NULL UNIQUE,
  customer_id INT NOT NULL,branch_id INT NOT NULL,zone_id INT NULL,
  order_type ENUM('delivery','takeaway') NOT NULL,
  status ENUM('new','confirmed','preparing','ready','out_for_delivery','delivered','cancelled') DEFAULT 'new',
  recipient_name VARCHAR(100),recipient_phone VARCHAR(20),
  delivery_address TEXT,delivery_area VARCHAR(100),delivery_notes TEXT,
  subtotal DECIMAL(10,2) NOT NULL,delivery_fee DECIMAL(10,2) DEFAULT 0,
  discount_amount DECIMAL(10,2) DEFAULT 0,tax_amount DECIMAL(10,2) DEFAULT 0,
  total_amount DECIMAL(10,2) NOT NULL,
  payment_method ENUM('cash','online') DEFAULT 'cash',
  payment_status ENUM('pending','paid') DEFAULT 'pending',
  coupon_id INT NULL,coupon_code VARCHAR(50),estimated_time INT,
  confirmed_at TIMESTAMP NULL,preparing_at TIMESTAMP NULL,ready_at TIMESTAMP NULL,
  dispatched_at TIMESTAMP NULL,delivered_at TIMESTAMP NULL,
  cancelled_at TIMESTAMP NULL,cancel_reason TEXT,
  customer_notes TEXT,admin_notes TEXT,
  rating TINYINT NULL,rating_comment TEXT,rated_at TIMESTAMP NULL,
  is_for_self TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (branch_id) REFERENCES branches(id),
  FOREIGN KEY (zone_id) REFERENCES delivery_zones(id) ON DELETE SET NULL,
  INDEX idx_status (status),INDEX idx_customer (customer_id),
  INDEX idx_branch (branch_id),INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,item_id INT NOT NULL,
  item_name VARCHAR(150) NOT NULL,size_name VARCHAR(50),
  quantity INT NOT NULL DEFAULT 1,unit_price DECIMAL(10,2) NOT NULL,
  extras_price DECIMAL(10,2) DEFAULT 0,total_price DECIMAL(10,2) NOT NULL,
  extras TEXT,notes TEXT,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (item_id) REFERENCES menu_items(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS coupon_usage (
  id INT AUTO_INCREMENT PRIMARY KEY,coupon_id INT NOT NULL,
  customer_id INT NOT NULL,order_id INT NOT NULL,
  discount_amount DECIMAL(10,2) NOT NULL,used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (coupon_id) REFERENCES coupons(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (order_id) REFERENCES orders(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS conversations (
  id INT AUTO_INCREMENT PRIMARY KEY,customer_id INT NULL,
  whatsapp_number VARCHAR(20) NOT NULL,session_id VARCHAR(100),
  state VARCHAR(50) DEFAULT 'greeting',cart TEXT,context TEXT,
  last_message_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
  INDEX idx_whatsapp (whatsapp_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS conversation_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,conversation_id INT NOT NULL,
  role ENUM('user','assistant') NOT NULL,message TEXT NOT NULL,
  message_type ENUM('text','image','audio','document') DEFAULT 'text',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,type VARCHAR(50),target VARCHAR(20),
  message TEXT,order_id INT NULL,status ENUM('pending','sent','failed') DEFAULT 'pending',
  sent_at TIMESTAMP NULL,error_message TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS admin_users (
  id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL,
  role ENUM('super_admin','admin','branch_manager') DEFAULT 'admin',
  branch_id INT NULL,is_active TINYINT(1) DEFAULT 1,last_login TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS activity_log (
  id INT AUTO_INCREMENT PRIMARY KEY,admin_id INT NULL,action VARCHAR(100),
  model VARCHAR(50),model_id INT,old_values TEXT,new_values TEXT,
  ip_address VARCHAR(45),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS peak_hours (
  id INT AUTO_INCREMENT PRIMARY KEY,branch_id INT NULL,day_of_week TINYINT NULL,
  start_time TIME NOT NULL,end_time TIME NOT NULL,
  extra_delivery_time INT DEFAULT 15,is_active TINYINT(1) DEFAULT 1,
  FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS faq (
  id INT AUTO_INCREMENT PRIMARY KEY,question VARCHAR(255) NOT NULL,
  answer TEXT NOT NULL,category VARCHAR(50) DEFAULT 'general',
  is_active TINYINT(1) DEFAULT 1,sort_order INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
SQLEOF

# Insert default data with dynamic password
ADMIN_HASH=$(php -r "echo password_hash('${ADMIN_PASS}', PASSWORD_DEFAULT);")
mysql -u botuser -p"${MYSQL_PASS}" restaurant_bot << DATAEOF
INSERT IGNORE INTO restaurant_settings (name, bot_name, welcome_message, bot_personality, closed_message) VALUES (
  '${RESTAURANT_NAME}', 'نور',
  'أهلاً وسهلاً! 🌟 أنا نور، مساعدتك في ${RESTAURANT_NAME}. كيف أقدر أساعدك النهارده؟',
  'أنت مساعد ذكي ودود اسمك نور. بتتكلم بالعربي بأسلوب ودي ومحترم. بتساعد العملاء في معرفة المنيو والطلب. بتقترح أطباق بناءً على طلبات العميل. دايماً إيجابي ومرحب.',
  'المطعم مغلق حالياً، سنعود قريباً! 🌙'
);
INSERT IGNORE INTO admin_users (name, email, password, role) VALUES (
  'المدير', 'admin@restaurant.com', '${ADMIN_HASH}', 'super_admin'
);
INSERT IGNORE INTO faq (question, answer, category) VALUES
('ما أوقات العمل؟', 'يعمل المطعم من 10 صباحاً حتى 12 منتصف الليل يومياً.', 'general'),
('كم وقت التوصيل؟', 'التوصيل يأخذ من 30 إلى 60 دقيقة حسب منطقتك.', 'delivery'),
('ما طرق الدفع المتاحة؟', 'نقبل الدفع كاش عند الاستلام.', 'payment');
DATAEOF

log "تم استيراد قاعدة البيانات"

# ════════════════════════════════════════════════════════════
# STEP 11: Copy PHP API files
# ════════════════════════════════════════════════════════════
info "نسخ ملفات PHP API..."

# index.php router
cat > /var/www/restaurant/index.php << 'PHPEOF'
<?php
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = preg_replace('#^/api/?#', '', $uri);
$uri = trim($uri, '/');
$parts = explode('/', $uri);
$resource = $parts[0] ?? '';
$action   = implode('/', array_slice($parts, 1));
$_GET['action'] = $action;

switch ($resource) {
    case 'menu':      require 'api/menu.php';      break;
    case 'orders':    require 'api/orders.php';    break;
    case 'branches':  require 'api/branches.php';  break;
    case 'customers': require 'api/customers.php'; break;
    case 'coupons':   require 'api/coupons.php';   break;
    case 'settings':  require 'api/settings.php';  break;
    case 'auth':      require 'api/auth.php';      break;
    case 'webhook':   require 'api/webhook.php';   break;
    case 'offers':    require 'api/offers.php';    break;
    case 'reports':   require 'api/reports.php';   break;
    case 'health':
        header('Content-Type: application/json');
        echo json_encode(['status'=>'ok','time'=>date('Y-m-d H:i:s')]);
        break;
    default:
        http_response_code(404);
        echo json_encode(['error'=>'Not found']);
}
PHPEOF

chown -R www-data:www-data /var/www/restaurant
log "تم نسخ ملفات PHP"

# ════════════════════════════════════════════════════════════
# STEP 12: Setup Node Bot
# ════════════════════════════════════════════════════════════
info "إعداد Node.js Bot..."
mkdir -p /var/www/restaurant/bot

cat > /var/www/restaurant/bot/package.json << 'NJEOF'
{
  "name": "restaurant-ai-bot",
  "version": "1.0.0",
  "main": "index.js",
  "scripts": { "start": "node index.js" },
  "dependencies": { "axios": "^1.6.0", "express": "^4.18.0" }
}
NJEOF

cat > /var/www/restaurant/bot/.env << ENVEOF
PHP_API_URL=http://localhost/api
GEMINI_API_KEY=${GEMINI_KEY}
WAHA_URL=http://localhost:3000
WAHA_API_KEY=${WAHA_KEY}
WAHA_SESSION=default
PORT=4000
RENDER_EXTERNAL_URL=http://${SERVER_IP}
ENVEOF

cd /var/www/restaurant/bot && npm install --quiet
log "تم إعداد Node Bot"

# ════════════════════════════════════════════════════════════
# STEP 13: Start WAHA via Docker
# ════════════════════════════════════════════════════════════
info "تشغيل WAHA (WhatsApp Engine)..."

# Stop existing if any
docker stop waha 2>/dev/null || true
docker rm waha 2>/dev/null || true

docker run -d \
  --name waha \
  --restart unless-stopped \
  -p 3000:3000 \
  -v /var/www/restaurant/waha-data:/app/.sessions \
  -e WHATSAPP_API_KEY="${WAHA_KEY}" \
  -e WHATSAPP_HOOK_URL="http://localhost:4000/webhook" \
  -e WHATSAPP_HOOK_EVENTS="message" \
  devlikeapro/waha:latest

sleep 5
if docker ps | grep -q waha; then
    log "تم تشغيل WAHA على port 3000"
else
    warn "WAHA لم يبدأ - تحقق بـ: docker logs waha"
fi

# ════════════════════════════════════════════════════════════
# STEP 14: Nginx Configuration
# ════════════════════════════════════════════════════════════
info "إعداد Nginx..."

cat > /etc/nginx/sites-available/restaurant << NGINXEOF
server {
    listen 80;
    server_name ${SERVER_IP} _;
    root /var/www/restaurant;
    index index.php index.html;
    client_max_body_size 10M;

    # ── Dashboard (React) ────────────────────────────────────
    location / {
        try_files \$uri \$uri/ /index.html;
        add_header Cache-Control "no-cache";
    }

    # ── PHP API ──────────────────────────────────────────────
    location /api/ {
        try_files \$uri \$uri/ /index.php?\$query_string;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root/index.php;
        include fastcgi_params;
        fastcgi_param REQUEST_URI \$request_uri;
        fastcgi_read_timeout 60;
    }

    # ── Static uploads ───────────────────────────────────────
    location /uploads/ {
        alias /var/www/restaurant/uploads/;
        expires 30d;
        add_header Cache-Control "public, immutable";
        add_header Access-Control-Allow-Origin "*";
    }

    # ── Bot webhook proxy ────────────────────────────────────
    location /bot/ {
        proxy_pass http://127.0.0.1:4000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 30;
    }

    # ── WAHA Dashboard (admin only) ──────────────────────────
    location /waha/ {
        proxy_pass http://127.0.0.1:3000/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }

    # ── Security headers ─────────────────────────────────────
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    # ── Logs ─────────────────────────────────────────────────
    access_log /var/log/nginx/restaurant.access.log;
    error_log  /var/log/nginx/restaurant.error.log;
}
NGINXEOF

# Enable site
ln -sf /etc/nginx/sites-available/restaurant /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test and reload
nginx -t && systemctl reload nginx
log "تم إعداد Nginx"

# ════════════════════════════════════════════════════════════
# STEP 15: PM2 Process Manager
# ════════════════════════════════════════════════════════════
info "إعداد PM2..."

cat > /var/www/restaurant/bot/ecosystem.config.js << 'PM2EOF'
module.exports = {
  apps: [{
    name: 'restaurant-bot',
    script: 'index.js',
    cwd: '/var/www/restaurant/bot',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '500M',
    env_file: '/var/www/restaurant/bot/.env',
    log_file: '/var/www/restaurant/logs/bot.log',
    error_file: '/var/www/restaurant/logs/bot-error.log',
    time: true,
    restart_delay: 5000,
  }]
};
PM2EOF

# Start bot (will fail gracefully if index.js not uploaded yet)
cd /var/www/restaurant/bot
pm2 start ecosystem.config.js 2>/dev/null || warn "Bot لم يبدأ — ارفع index.js أولاً"
pm2 save

log "تم إعداد PM2"

# ════════════════════════════════════════════════════════════
# STEP 16: Firewall
# ════════════════════════════════════════════════════════════
info "إعداد Firewall..."
ufw --force reset > /dev/null
ufw default deny incoming > /dev/null
ufw default allow outgoing > /dev/null
ufw allow ssh > /dev/null
ufw allow 80/tcp > /dev/null
ufw allow 443/tcp > /dev/null
ufw --force enable > /dev/null
log "تم إعداد Firewall (SSH + HTTP + HTTPS مفتوحة)"

# ════════════════════════════════════════════════════════════
# STEP 17: Auto-backup script
# ════════════════════════════════════════════════════════════
info "إعداد النسخ الاحتياطي التلقائي..."

cat > /usr/local/bin/restaurant-backup.sh << BACKUPEOF
#!/bin/bash
BACKUP_DIR="/var/backups/restaurant"
DATE=\$(date +%Y%m%d_%H%M)
mkdir -p \$BACKUP_DIR

# DB backup
mysqldump -u botuser -p'${MYSQL_PASS}' restaurant_bot | gzip > \$BACKUP_DIR/db_\$DATE.sql.gz

# Keep last 7 days only
find \$BACKUP_DIR -name "db_*.sql.gz" -mtime +7 -delete

echo "Backup done: db_\$DATE.sql.gz"
BACKUPEOF

chmod +x /usr/local/bin/restaurant-backup.sh
# Run daily at 3 AM
(crontab -l 2>/dev/null; echo "0 3 * * * /usr/local/bin/restaurant-backup.sh >> /var/log/restaurant-backup.log 2>&1") | crontab -
log "تم إعداد النسخ الاحتياطي (يومياً الساعة 3 صباحاً)"

# ════════════════════════════════════════════════════════════
# STEP 18: Management helper script
# ════════════════════════════════════════════════════════════
cat > /usr/local/bin/restaurant << 'MGMTEOF'
#!/bin/bash
case "$1" in
  status)
    echo "=== Services ==="
    systemctl is-active --quiet nginx && echo "✅ Nginx: running" || echo "❌ Nginx: stopped"
    systemctl is-active --quiet php8.1-fpm && echo "✅ PHP-FPM: running" || echo "❌ PHP-FPM: stopped"
    systemctl is-active --quiet mysql && echo "✅ MySQL: running" || echo "❌ MySQL: stopped"
    docker ps --filter name=waha --format "✅ WAHA: {{.Status}}" 2>/dev/null || echo "❌ WAHA: stopped"
    pm2 list
    ;;
  restart)
    systemctl restart nginx php8.1-fpm mysql
    pm2 restart restaurant-bot
    echo "✅ All services restarted"
    ;;
  logs)
    case "$2" in
      bot)   pm2 logs restaurant-bot --lines 50 ;;
      nginx) tail -50 /var/log/nginx/restaurant.error.log ;;
      waha)  docker logs --tail 50 waha ;;
      *)     pm2 logs restaurant-bot --lines 20 ;;
    esac
    ;;
  bot)
    case "$2" in
      restart) pm2 restart restaurant-bot && echo "✅ Bot restarted" ;;
      stop)    pm2 stop restaurant-bot && echo "⏹️ Bot stopped" ;;
      start)   pm2 start restaurant-bot && echo "✅ Bot started" ;;
    esac
    ;;
  waha)
    case "$2" in
      restart) docker restart waha && echo "✅ WAHA restarted" ;;
      stop)    docker stop waha && echo "⏹️ WAHA stopped" ;;
      qr)      echo "افتح: http://$(curl -s ifconfig.me):80/waha/dashboard" ;;
    esac
    ;;
  backup)  /usr/local/bin/restaurant-backup.sh ;;
  domain)
    if [ -z "$2" ]; then echo "Usage: restaurant domain yourdomain.com"; exit 1; fi
    DOMAIN=$2
    # Update nginx config
    sed -i "s/server_name .*/server_name $DOMAIN;/" /etc/nginx/sites-available/restaurant
    # Update PHP config
    sed -i "s|define('APP_URL'.*|define('APP_URL', 'https://$DOMAIN');|" /var/www/restaurant/config.php
    sed -i "s|define('UPLOAD_URL'.*|define('UPLOAD_URL', 'https://$DOMAIN/uploads/');|" /var/www/restaurant/config.php
    nginx -t && systemctl reload nginx
    # Get SSL
    apt-get install -y -qq certbot python3-certbot-nginx
    certbot --nginx -d $DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN
    echo "✅ Domain $DOMAIN configured with SSL"
    ;;
  *)
    echo "🍽️ Restaurant Bot Manager"
    echo ""
    echo "Usage: restaurant <command>"
    echo ""
    echo "Commands:"
    echo "  status          — حالة كل الخدمات"
    echo "  restart         — إعادة تشغيل كل حاجة"
    echo "  logs [bot|nginx|waha]  — عرض اللوجز"
    echo "  bot [restart|stop|start]"
    echo "  waha [restart|stop|qr]"
    echo "  backup          — نسخة احتياطية"
    echo "  domain example.com — إضافة دومين + SSL"
    ;;
esac
MGMTEOF
chmod +x /usr/local/bin/restaurant

# ════════════════════════════════════════════════════════════
# DONE - Print Summary
# ════════════════════════════════════════════════════════════
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║            ✅ التثبيت اكتمل بنجاح!                  ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}📌 روابط مهمة:${NC}"
echo -e "   🌐 API:            http://${SERVER_IP}/api/health"
echo -e "   📱 WAHA Dashboard: http://${SERVER_IP}/waha/dashboard"
echo -e "   🔑 Admin Login:    admin@restaurant.com / ${ADMIN_PASS}"
echo ""
echo -e "${GREEN}📋 بيانات قاعدة البيانات:${NC}"
echo -e "   DB Name:  restaurant_bot"
echo -e "   DB User:  botuser"
echo -e "   DB Pass:  ${MYSQL_PASS}"
echo ""
echo -e "${YELLOW}⚠️  الخطوات التالية:${NC}"
echo -e "   1️⃣  ارفع ملفات PHP API على /var/www/restaurant/api/"
echo -e "   2️⃣  ارفع ملف index.js على /var/www/restaurant/bot/"
echo -e "   3️⃣  شغّل البوت: pm2 restart restaurant-bot"
echo -e "   4️⃣  امسح QR Code من: http://${SERVER_IP}/waha/dashboard"
echo -e "   5️⃣  ارفع الداشبورد على /var/www/restaurant/ (build)"
echo ""
echo -e "${GREEN}💡 أوامر مفيدة:${NC}"
echo -e "   restaurant status     — حالة كل الخدمات"
echo -e "   restaurant logs bot   — لوجز البوت"
echo -e "   restaurant waha qr    — رابط QR Code"
echo -e "   restaurant domain yourdomain.com — إضافة دومين"
echo ""
echo -e "${GREEN}📁 مسارات المشروع:${NC}"
echo -e "   /var/www/restaurant/        — المشروع"
echo -e "   /var/www/restaurant/api/    — PHP API files"
echo -e "   /var/www/restaurant/bot/    — Node Bot"
echo -e "   /var/www/restaurant/uploads/ — الصور"
echo -e "   /var/backups/restaurant/    — النسخ الاحتياطية"
echo ""

# Save credentials to file
cat > /root/restaurant-credentials.txt << CREDSEOF
=======================================
Restaurant Bot - Credentials
=======================================
Server IP:     ${SERVER_IP}
DB Password:   ${MYSQL_PASS}
WAHA API Key:  ${WAHA_KEY}
JWT Secret:    ${JWT_SECRET}
Admin Email:   admin@restaurant.com
Admin Pass:    ${ADMIN_PASS}
Gemini Key:    ${GEMINI_KEY}
=======================================
WAHA Dashboard: http://${SERVER_IP}/waha/dashboard
API Health:     http://${SERVER_IP}/api/health
=======================================
CREDSEOF
chmod 600 /root/restaurant-credentials.txt
echo -e "${YELLOW}💾 البيانات محفوظة في: /root/restaurant-credentials.txt${NC}"
